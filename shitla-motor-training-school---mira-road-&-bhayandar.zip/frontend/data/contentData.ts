import { Branch, Course, FaqItem, RTOQuestion } from '../types';

export const BRANCHES_DATA: Branch[] = [
  {
    id: 'mira-road-east-station',
    name: 'Shitla Motor Training - Mira Road East (Station Road)',
    locality: 'mira-road',
    subArea: 'Mira Road East',
    address: 'Shop No. 7, Shanti Shopping Centre, Opp. Mira Road Railway Station Platform 1, Mira Road East, Thane 401107',
    landmark: 'Opposite Railway Station & Shanti Nagar Market',
    phone: '+91 98205 12341',
    whatsapp: '919820512341',
    email: 'miraroad.east@shitlamotors.com',
    timing: 'Mon - Sun: 6:00 AM - 9:00 PM',
    geo: { lat: 19.2812, lng: 72.8561 },
    pickupPoints: ['Mira Road Station', 'Shanti Nagar Sector 1 to 8', 'Kanakia Road', 'Beverly Park', 'Silver Park'],
    features: ['Dual-Control AC Swift & WagonR', 'Certified Lady Instructors Available', 'Govt RTO Authorized Driving Track', 'Instant Learner License Form Filling'],
    rating: 4.9,
    reviewsCount: 428,
    rtoZone: 'MH-04 Thane RTO'
  },
  {
    id: 'mira-road-kanakia',
    name: 'Shitla Motor Training - Beverly Park & Kanakia',
    locality: 'mira-road',
    subArea: 'Mira Road East - Highway Connector',
    address: 'Ground Floor, Jangid Complex, Near Cinemax / Beverly Park, Kanakia Road, Mira Road East, 401107',
    landmark: 'Near Cinemax WonderMall & GCC Club',
    phone: '+91 98205 12342',
    whatsapp: '919820512342',
    email: 'kanakia@shitlamotors.com',
    timing: 'Mon - Sun: 6:30 AM - 9:00 PM',
    geo: { lat: 19.2896, lng: 72.8712 },
    pickupPoints: ['Kanakia Park', 'Jangid Enclave', 'GCC Club Road', 'Poonam Sagar Complex', 'Pleasant Park'],
    features: ['Automatic AMT / CVT Training', 'Highway Driving on Western Express Highway', 'Weekend Fast-Track Batches', 'Simulator Session Room'],
    rating: 4.8,
    reviewsCount: 310,
    rtoZone: 'MH-04 Thane RTO'
  },
  {
    id: 'bhayandar-west-maxus',
    name: 'Shitla Motor Training - Bhayandar West (Maxus Mall)',
    locality: 'bhayandar',
    subArea: 'Bhayandar West',
    address: 'Shop 12, Shree Ram Arcade, 150 Feet Road, Near Maxus Mall, Bhayandar West, Thane 401101',
    landmark: 'Adjacent to Maxus Mall & D-Mart 150ft Road',
    phone: '+91 98205 12343',
    whatsapp: '919820512343',
    email: 'bhayandar.west@shitlamotors.com',
    timing: 'Mon - Sun: 6:00 AM - 8:30 PM',
    geo: { lat: 19.3032, lng: 72.8425 },
    pickupPoints: ['Maxus Mall Circle', '150 Feet Road', 'Balaji Nagar', 'Tathastu Complex', 'Bhayandar West Station'],
    features: ['Spacious 8-Shape & H-Shape Driving Track', 'Dual-Fuel (Petrol/CNG) & Automatic Cars', 'Dedicated Lady Instructor Squad', 'Pick & Drop Facilities'],
    rating: 4.9,
    reviewsCount: 512,
    rtoZone: 'MH-04 Thane RTO'
  },
  {
    id: 'bhayandar-east-navghar',
    name: 'Shitla Motor Training - Bhayandar East (Navghar)',
    locality: 'bhayandar',
    subArea: 'Bhayandar East',
    address: 'Unit 4, Sai Krupa Building, Navghar Road, Near Flyover Bridge, Bhayandar East, Thane 401105',
    landmark: 'Near Navghar Police Station & Golden Nest Circle',
    phone: '+91 98205 12344',
    whatsapp: '919820512344',
    email: 'navghar@shitlamotors.com',
    timing: 'Mon - Sun: 6:00 AM - 9:00 PM',
    geo: { lat: 19.3085, lng: 72.8598 },
    pickupPoints: ['Golden Nest Circle', 'Navghar Phatak', 'Indralok Phase 1-6', 'Jesal Park', 'Station Flyover'],
    features: ['Heavy Vehicle & Commercial Endorsement', 'Two Wheeler + Four Wheeler Combo', 'Night Driving Sessions', 'Free Mock RTO Computer Test'],
    rating: 4.9,
    reviewsCount: 389,
    rtoZone: 'MH-04 Thane RTO'
  }
];

export const COURSES_DATA: Course[] = [
  {
    id: 'four-wheeler-manual-comprehensive',
    title: '4-Wheeler Manual Transmission (Comprehensive Master)',
    category: 'four-wheeler',
    transmission: 'Manual',
    durationDays: 20,
    sessionMinutes: 30,
    price: 6499,
    originalPrice: 8500,
    popular: true,
    features: [
      'Daily 30 Mins Practical Driving on Roads & Traffic',
      'Dual-Control Maruti Swift / WagonR AC',
      'Complete RTO Thane License (LL + DL) included',
      'Clutch balance, bumper-to-bumper & reverse parking',
      'Flyover & incline slope hill-start techniques'
    ],
    syllabus: [
      'Day 1-3: Controls layout, ABC (Accelerator, Brake, Clutch), Gear Shift',
      'Day 4-7: Steering wheel grip, lane positioning, smooth braking',
      'Day 8-12: Peak traffic driving in Mira Road market & Western Express Highway',
      'Day 13-16: Parallel parking, Angular parking, Reverse H-Track',
      'Day 17-20: RTO test rehearsal on official track + Night drive introduction'
    ],
    rtoAssistanceIncluded: true
  },
  {
    id: 'four-wheeler-automatic-pro',
    title: '4-Wheeler Automatic (AMT/CVT) Urban Driving Course',
    category: 'four-wheeler',
    transmission: 'Automatic',
    durationDays: 15,
    sessionMinutes: 30,
    price: 7499,
    originalPrice: 9500,
    popular: true,
    features: [
      'Latest Automatic Cars (Hyundai i10 / Baleno AMT)',
      'Stress-free left leg comfort for Mumbai traffic',
      'Creep function, hill-hold, overtaking protocols',
      'RTO Learner & Permanent Driving License covered',
      'Female trainer option on request at zero extra cost'
    ],
    syllabus: [
      'Day 1-2: P-R-N-D gear selector, one-foot pedal discipline',
      'Day 3-6: Speed modulation, judging tight lanes & junctions',
      'Day 7-10: Highway cruising on Ghodbunder / WEH & toll plaza etiquette',
      'Day 11-13: Smart sensor & camera-guided reverse parking',
      'Day 14-15: Final RTO evaluation & defensive night driving'
    ],
    rtoAssistanceIncluded: true
  },
  {
    id: 'two-wheeler-mastery',
    title: '2-Wheeler (Geared Motorcycle & Non-Geared Activa)',
    category: 'two-wheeler',
    transmission: 'Both',
    durationDays: 12,
    sessionMinutes: 30,
    price: 3499,
    originalPrice: 4500,
    features: [
      'Balance practice on Honda Activa or Hero Splendor',
      'Figure-8 track maneuvers for RTO test clearance',
      'RTO 2-Wheeler Driver License included',
      'Protective helmet and safety knee pads provided',
      'Road signage & emergency braking training'
    ],
    syllabus: [
      'Day 1-3: Balance stabilization, low-speed throttle control',
      'Day 4-6: U-turns, sharp turns & Figure-8 track drill',
      'Day 7-9: Braking balance (Front vs Rear) & rainy road caution',
      'Day 10-12: Colony & main street traffic + RTO test demo'
    ],
    rtoAssistanceIncluded: true
  },
  {
    id: 'combo-2w-4w-all-in-one',
    title: 'All-in-One Super Saver Combo (Car + Bike/Scooter)',
    category: 'combo',
    transmission: 'Both',
    durationDays: 25,
    sessionMinutes: 45,
    price: 8999,
    originalPrice: 12000,
    features: [
      'Both 4-Wheeler (Manual/Auto) & 2-Wheeler combined',
      'Single RTO Smart Card Driving License for MCWG + LMV',
      'Highest value package for beginners & college students',
      'Flexible scheduling across morning or evening slots'
    ],
    syllabus: [
      'Phase 1: 2-Wheeler balance & Figure-8 mastering (7 Days)',
      'Phase 2: 4-Wheeler cockpit basics & road drives (15 Days)',
      'Phase 3: Joint RTO Test at Thane RTO ground (3 Days)'
    ],
    rtoAssistanceIncluded: true
  },
  {
    id: 'refresher-confidence-booster',
    title: 'Refresher Course for Existing License Holders',
    category: 'refresher',
    transmission: 'Both',
    durationDays: 7,
    sessionMinutes: 45,
    price: 3999,
    originalPrice: 5500,
    features: [
      'Designed for people who have a license but lack road confidence',
      'Drive in our dual-control car or get coached in your OWN CAR',
      'Mira-Bhayandar flyovers, basement mall parking & night driving',
      'No RTO paperwork required - 100% focused on confidence booster'
    ],
    syllabus: [
      'Day 1: Driving posture, blind-spot mirror alignment, confidence assessment',
      'Day 2-3: Dealing with Mumbai bumper traffic, aggressive auto-rickshaws',
      'Day 4: Basement mall parking at Maxus Mall or Cinemax',
      'Day 5-6: Highway speed driving on NH-48 / Western Express',
      'Day 7: Independent drive evaluation with constructive feedback'
    ],
    rtoAssistanceIncluded: false
  }
];

export const FAQ_DATA: FaqItem[] = [
  {
    question: 'Where are Shitla Motor Training School branches located in Mira Road and Bhayandar?',
    answer: 'We have 4 strategic branches: Mira Road East (opposite Railway Station Platform 1), Mira Road Kanakia/Beverly Park (near Cinemax), Bhayandar West (near Maxus Mall 150ft Road), and Bhayandar East (Navghar Road near flyover). Doorstep pickup is available across all sectors of Mira-Bhayandar.',
    category: 'Admission & Fees'
  },
  {
    question: 'How long does it take to get a permanent driving license from Thane RTO (MH-04)?',
    answer: 'Once you enroll, we issue your RTO Learner’s License (LL) within 24-48 hours. As per Maharashtra RTO rules, you are eligible for the Permanent Driving License (DL) test after 30 days of LL issuance. Our package covers end-to-end document processing, appointment booking, and vehicle escort at the Thane RTO test ground.',
    category: 'RTO License (MH-04)'
  },
  {
    question: 'Do you offer certified female driving instructors for women learners?',
    answer: 'Yes! Shitla Motor Training School has a dedicated team of certified, patient female instructors for lady candidates in both Mira Road and Bhayandar. You can request a female instructor when booking online at zero extra surcharge.',
    category: 'Safety & Ladies Special'
  },
  {
    question: 'What documents are required to register for driving training and RTO license?',
    answer: 'You only need: 1. Aadhaar Card (with updated mobile number for OTP), 2. Age proof (Birth Certificate, 10th School Leaving Certificate, or PAN Card), 3. Blood group report, and 4. Three passport-size photographs. Address in Mira-Bhayandar or Mumbai MMR is eligible under Thane MH-04 jurisdiction.',
    category: 'Admission & Fees'
  },
  {
    question: 'Can I learn on an Automatic Car (AMT/CVT/AT)?',
    answer: 'Absolutely. We provide dedicated training on automatic cars (like Maruti Swift/Baleno & Hyundai i10 AMT). It is extremely popular among commuters facing daily stop-and-go traffic on Kashimira junction, Dahisar Toll, and the Western Express Highway.',
    category: 'Training & Car Types'
  },
  {
    question: 'What happens if I fail the RTO driving test on the first attempt?',
    answer: 'We maintain a 98.4% first-time passing rate! In the rare case of a test retake, our instructors provide extra rehearsal sessions on the Thane RTO track, and we re-schedule your official slot with minimal administrative fees.',
    category: 'RTO License (MH-04)'
  }
];

export const RTO_MOCK_QUESTIONS: RTOQuestion[] = [
  {
    id: 1,
    question: 'What does a red circular traffic sign with a straight arrow crossed by a red diagonal bar indicate?',
    options: ['No Entry / Prohibited Direction', 'One Way Traffic', 'Overtaking Prohibited', 'Speed Limit Ahead'],
    correctIndex: 0,
    explanation: 'Circular signs with red borders indicate prohibitions or mandatory restrictions. A crossed arrow signifies No Entry.',
    category: 'Traffic Sign'
  },
  {
    id: 2,
    question: 'What is the minimum age required to apply for a private four-wheeler (LMV) license in Maharashtra?',
    options: ['16 Years', '18 Years', '20 Years', '21 Years'],
    correctIndex: 1,
    explanation: 'As per the Motor Vehicles Act, the minimum age for a Light Motor Vehicle (LMV) driving license is 18 years.',
    category: 'Rules & Regulations'
  },
  {
    id: 3,
    question: 'When approaching an unmanned railway level crossing, what is the driver required to do before crossing?',
    options: [
      'Honk loud and cross immediately',
      'Stop the vehicle, get down or check both railway tracks clearly before proceeding',
      'Speed up to clear the track quickly',
      'Follow the vehicle in front closely'
    ],
    correctIndex: 1,
    explanation: 'The driver must stop, observe left and right, and ensure no train is approaching before crossing safely.',
    category: 'Road Safety'
  },
  {
    id: 4,
    question: 'What does an inverted triangular road sign mean?',
    options: ['Stop', 'Give Way / Yield', 'Compulsory Turn Left', 'Pedestrian Crossing'],
    correctIndex: 1,
    explanation: 'An inverted triangle is universally designated as the Give Way (Yield) regulatory sign.',
    category: 'Traffic Sign'
  },
  {
    id: 5,
    question: 'How many days after obtaining a Learner’s License can you apply for a Permanent Driving License test?',
    options: ['15 Days', '30 Days', '60 Days', '90 Days'],
    correctIndex: 1,
    explanation: 'A learner can book a driving test 30 days after the date of Learner License issuance (and within 6 months validity).',
    category: 'Rules & Regulations'
  }
];

export const LOCAL_SEO_KEYWORDS = [
  'Best driving school in Mira Road East',
  'Car driving training in Bhayandar West',
  'Female driving instructor in Mira Bhayandar',
  'Automatic car driving classes near Shanti Nagar',
  'Thane RTO MH04 license agent and motor training',
  'Two wheeler scooty learning school Bhayandar',
  'Dual control driving school near Maxus Mall',
  'Motor driving fees in Mira Road 2025'
];
