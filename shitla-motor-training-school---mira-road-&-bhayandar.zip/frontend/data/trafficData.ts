import { TrafficHotspot, HourlyTrafficData } from '../types';

export const HOURLY_TRAFFIC_DATA: HourlyTrafficData[] = [
  { timeSlot: '06:00 AM', miraRoadEast: 18, bhayandarWest: 15, highwayWEH: 22, recommendation: 'Ideal for Beginners' },
  { timeSlot: '07:00 AM', miraRoadEast: 28, bhayandarWest: 24, highwayWEH: 38, recommendation: 'Ideal for Beginners' },
  { timeSlot: '08:00 AM', miraRoadEast: 62, bhayandarWest: 58, highwayWEH: 76, recommendation: 'Heavy Traffic Practice' },
  { timeSlot: '09:00 AM', miraRoadEast: 88, bhayandarWest: 79, highwayWEH: 94, recommendation: 'Extreme Stress Training' },
  { timeSlot: '10:00 AM', miraRoadEast: 82, bhayandarWest: 72, highwayWEH: 86, recommendation: 'Heavy Traffic Practice' },
  { timeSlot: '11:00 AM', miraRoadEast: 46, bhayandarWest: 42, highwayWEH: 54, recommendation: 'Smooth Cruising' },
  { timeSlot: '12:00 PM', miraRoadEast: 38, bhayandarWest: 35, highwayWEH: 45, recommendation: 'Smooth Cruising' },
  { timeSlot: '01:00 PM', miraRoadEast: 32, bhayandarWest: 30, highwayWEH: 40, recommendation: 'Smooth Cruising' },
  { timeSlot: '02:00 PM', miraRoadEast: 30, bhayandarWest: 28, highwayWEH: 38, recommendation: 'Smooth Cruising' },
  { timeSlot: '03:00 PM', miraRoadEast: 40, bhayandarWest: 36, highwayWEH: 48, recommendation: 'Smooth Cruising' },
  { timeSlot: '04:00 PM', miraRoadEast: 55, bhayandarWest: 48, highwayWEH: 62, recommendation: 'Intermediate Maneuvers' as any },
  { timeSlot: '05:00 PM', miraRoadEast: 74, bhayandarWest: 68, highwayWEH: 84, recommendation: 'Heavy Traffic Practice' },
  { timeSlot: '06:00 PM', miraRoadEast: 92, bhayandarWest: 85, highwayWEH: 96, recommendation: 'Extreme Stress Training' },
  { timeSlot: '07:00 PM', miraRoadEast: 95, bhayandarWest: 89, highwayWEH: 98, recommendation: 'Extreme Stress Training' },
  { timeSlot: '08:00 PM', miraRoadEast: 84, bhayandarWest: 78, highwayWEH: 88, recommendation: 'Heavy Traffic Practice' },
  { timeSlot: '09:00 PM', miraRoadEast: 54, bhayandarWest: 50, highwayWEH: 60, recommendation: 'Night Driving Practice' as any },
];

export const TRAFFIC_HOTSPOTS_DATA: TrafficHotspot[] = [
  {
    id: 'kashimira-weh',
    name: 'Kashimira Naka & Western Express Highway Junction',
    locality: 'Highway Corridor',
    congestionLevel: 'Critical',
    congestionScore: 92,
    avgSpeedKmh: 14,
    difficultyRating: 5,
    recommendedSkillLevel: 'Advanced (Day 13-20)',
    bestTrainingWindow: '06:30 AM - 07:45 AM or 01:00 PM - 03:00 PM',
    keyHazards: ['Heavy multi-axle freight trucks', 'Dahisar toll lane merges', 'Flyover pillar blind spots', 'Unpredictable two-wheeler overtaking'],
    instructorTip: 'Maintain a 2-second distance buffer. Never ride the clutch on the flyover merge; use handbrake incline balancing.',
    clutchStrainIndex: 'Severe'
  },
  {
    id: 'shanti-nagar-station',
    name: 'Mira Road Station Road & Shanti Nagar Market',
    locality: 'Mira Road',
    congestionLevel: 'Heavy',
    congestionScore: 84,
    avgSpeedKmh: 12,
    difficultyRating: 4,
    recommendedSkillLevel: 'Intermediate (Day 6-12)',
    bestTrainingWindow: '06:00 AM - 08:00 AM or 02:00 PM - 04:00 PM',
    keyHazards: ['Shared auto-rickshaws making abrupt stops', 'Pedestrian street vendors', 'Tight angular parking slots', 'Sharp 90-degree turns'],
    instructorTip: 'Keep eyes at 15-meter horizon. Shift to 2nd gear and hover foot gently above the brake pedal rather than accelerating unnecessarily.',
    clutchStrainIndex: 'High'
  },
  {
    id: 'maxus-mall-150ft',
    name: 'Maxus Mall & 150 Feet Road Corridor (Bhayandar West)',
    locality: 'Bhayandar',
    congestionLevel: 'Moderate',
    congestionScore: 48,
    avgSpeedKmh: 34,
    difficultyRating: 2,
    recommendedSkillLevel: 'Beginner (Day 1-5)',
    bestTrainingWindow: '06:00 AM - 10:00 AM (Broad 6-lane road)',
    keyHazards: ['Median U-turn cross-traffic', 'Roundabout lane discipline', 'Cyclists near D-Mart', 'Speed humps near residential complexes'],
    instructorTip: 'Best open training stretch in Thane district for mastering 3rd to 4th gear transition, side-mirror checking, and smooth braking.',
    clutchStrainIndex: 'Low'
  },
  {
    id: 'golden-nest-circle',
    name: 'Golden Nest Circle & Flyover Approach',
    locality: 'Mira Road',
    congestionLevel: 'Heavy',
    congestionScore: 78,
    avgSpeedKmh: 18,
    difficultyRating: 4,
    recommendedSkillLevel: 'Intermediate (Day 6-12)',
    bestTrainingWindow: '11:00 AM - 03:30 PM',
    keyHazards: ['Multi-spoke traffic convergence', 'Steep flyover incline starting', 'Bus stops right before turn', 'Signal countdown rushing'],
    instructorTip: 'Essential RTO preparation spot for Hill Hold & slope restart test without stalling or rolling backward.',
    clutchStrainIndex: 'High'
  },
  {
    id: 'kanakia-beverly-park',
    name: 'Beverly Park, Kanakia Road & GCC Club Loop',
    locality: 'Mira Road',
    congestionLevel: 'Low',
    congestionScore: 32,
    avgSpeedKmh: 28,
    difficultyRating: 2,
    recommendedSkillLevel: 'Beginner (Day 1-5)',
    bestTrainingWindow: '06:00 AM - 09:30 AM & 02:00 PM - 04:30 PM',
    keyHazards: ['Speed humps inside society gates', 'Parked cars narrowing single lanes', 'School bus drop-off points'],
    instructorTip: 'Where our instructors take first-timers on Day 1. Gentle curves, wide dividers, and patient local drivers.',
    clutchStrainIndex: 'Low'
  },
  {
    id: 'navghar-jesal-park',
    name: 'Navghar Phatak & Jesal Park Creekside Ring',
    locality: 'Bhayandar',
    congestionLevel: 'Moderate',
    congestionScore: 56,
    avgSpeedKmh: 22,
    difficultyRating: 3,
    recommendedSkillLevel: 'Intermediate (Day 6-12)',
    bestTrainingWindow: '07:00 AM - 10:30 AM or 03:00 PM - 05:00 PM',
    keyHazards: ['Narrow railway overbridge connector', 'Two-wheeler swarms near station entrance', 'Creek breeze crosswinds'],
    instructorTip: 'Ideal circuit for reverse H-track simulation and parallel parking between real road curbs.',
    clutchStrainIndex: 'Medium'
  }
];

export const LOCAL_SEARCH_TRAFFIC_STATS = [
  { keyword: 'driving school mira road', monthlySearches: 4400, rankStatus: '#1 on Google Map Pack' },
  { keyword: 'motor training school bhayandar west', monthlySearches: 3200, rankStatus: '#1 Organic & Local' },
  { keyword: 'lady driving instructor mira road', monthlySearches: 1850, rankStatus: 'Featured Snippet' },
  { keyword: 'thane rto mh04 license agent', monthlySearches: 2900, rankStatus: 'Top 3 Ranking' },
  { keyword: 'automatic car driving classes bhayandar', monthlySearches: 1600, rankStatus: '#1 Local Pack' },
];
