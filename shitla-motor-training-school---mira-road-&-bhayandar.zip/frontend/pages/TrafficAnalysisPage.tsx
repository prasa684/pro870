import React, { useState } from 'react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Compass, 
  Car, 
  Gauge, 
  Info, 
  MapPin, 
  Navigation, 
  ShieldAlert, 
  Sparkles, 
  TrendingUp, 
  Calendar,
  Zap,
  ArrowRight,
  Filter
} from 'lucide-react';
import { HOURLY_TRAFFIC_DATA, TRAFFIC_HOTSPOTS_DATA, LOCAL_SEARCH_TRAFFIC_STATS } from '../data/trafficData';
import { GoogleGenAI } from '@google/genai';

interface TrafficAnalysisPageProps {
  onOpenBooking: (courseId?: string, branchId?: string) => void;
  onOpenAdvisor: () => void;
}

export const TrafficAnalysisPage: React.FC<TrafficAnalysisPageProps> = ({
  onOpenBooking,
  onOpenAdvisor,
}) => {
  const [selectedHotspot, setSelectedHotspot] = useState(TRAFFIC_HOTSPOTS_DATA[0]);
  const [localityFilter, setLocalityFilter] = useState<'All' | 'Mira Road' | 'Bhayandar' | 'Highway Corridor'>('All');
  const [skillFilter, setSkillFilter] = useState<string>('All');
  
  // Custom AI Route Recommendation state
  const [learnerConfidence, setLearnerConfidence] = useState<'beginner' | 'intermediate' | 'nervous' | 'experienced'>('beginner');
  const [preferredTransmission, setPreferredTransmission] = useState<'manual' | 'automatic'>('manual');
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);

  const filteredHotspots = TRAFFIC_HOTSPOTS_DATA.filter((item) => {
    const matchLoc = localityFilter === 'All' || item.locality === localityFilter;
    const matchSkill = skillFilter === 'All' || item.recommendedSkillLevel.includes(skillFilter);
    return matchLoc && matchSkill;
  });

  const handleGenerateRouteAdvice = async () => {
    setAiGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY, vertexai: true });
      const prompt = `
You are the Chief Traffic Dispatcher & Senior Driving Instructor at Shitla Motor Training School in Mira Road & Bhayandar (Thane MH-04).
Analyze the learner's profile:
- Skill Level: ${learnerConfidence}
- Transmission: ${preferredTransmission}
- Region: Mira Road East & Bhayandar West

Key Hotspots in our training database:
1. Maxus Mall 150ft road (Bhayandar West) - Wide, 6-lane, calm morning hours
2. Beverly Park & Kanakia loop (Mira Road) - Low traffic, gentle curves
3. Shanti Nagar Station Road (Mira Road) - High pedestrian, market, auto swarms
4. Golden Nest Circle & Flyover - Incline slope test, multi-lane circle
5. Kashimira Naka & WEH - Heavy freight, fast traffic, flyover merging

Provide a crisp 3-part custom training itinerary:
1. "Stage 1 Best Road & Hours" (Where to start with least anxiety)
2. "Traffic Progression Strategy" (When to graduate to high-stress junctions)
3. "Pro Coach Secret for ${preferredTransmission} drivers in Mira-Bhayandar"
Keep it professional, encouraging, and local to Mira-Bhayandar landmarks. Keep under 170 words.
`;
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      setAiAdvice(response.text || 'Our instructors recommend starting at Kanakia Road or Maxus 150ft Road between 6:30 AM and 8:00 AM before tackling Kashimira Naka!');
    } catch (err) {
      console.error(err);
      setAiAdvice(
        'Recommended Path: Begin on the broad 150 Feet Road near Maxus Mall, Bhayandar West between 6:00 AM - 8:00 AM. Once comfortable with smooth steering, graduate to Golden Nest Circle at 11:30 AM to master incline stops!'
      );
    } finally {
      setAiGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Header Banner */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-50 border border-brand-200 text-brand-700 text-xs font-bold uppercase tracking-wider">
          <Compass className="w-3.5 h-3.5 text-brand-600" />
          <span>Local Route Intelligence & Road Congestion Index</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Mira Road & Bhayandar Traffic Analysis
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          How Shitla Motor Training plans scientific driving routes. We analyze peak congestion hours, clutch strain indices, and incline slope hurdles so you master real Mumbai traffic without panic.
        </p>
      </div>

      {/* Real-Time Congestion Index Snapshot */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>Overall Congestion</span>
            <Gauge className="w-4 h-4 text-brand-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">46%</div>
          <p className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Optimal for practical lessons
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>Calmest Training Window</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-600">6 - 8 AM</div>
          <p className="text-[11px] text-slate-500">Zero freight, wide empty lanes</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>Peak Stress Window</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-600">6 - 8 PM</div>
          <p className="text-[11px] text-rose-700 font-medium">Bumper-to-bumper testing</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>1st Try RTO Pass Rate</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-600">98.4%</div>
          <p className="text-[11px] text-slate-500">Powered by route mapping</p>
        </div>
      </div>

      {/* Hourly Congestion Chart (Recharts) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              Hourly Traffic Intensity in Mira-Bhayandar (6 AM - 9 PM)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Comparison of vehicle density percentage across Mira Road East, Bhayandar West, and the Western Express Highway (WEH).
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1 font-semibold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200">
              ● Mira Road East
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              ● Bhayandar West
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-md border border-rose-200">
              ● WEH Highway
            </span>
          </div>
        </div>

        {/* Recharts Area Chart */}
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={HOURLY_TRAFFIC_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorMira" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0}/>
                </linearGradient>
                <linearGradient id="colorBhayandar" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                </linearGradient>
                <linearGradient id="colorWeh" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="timeSlot" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                formatter={(val: number) => [`${val}% Congestion Index`]}
              />
              <Area type="monotone" dataKey="miraRoadEast" name="Mira Road East" stroke="#0284c7" strokeWidth={2} fillOpacity={1} fill="url(#colorMira)" />
              <Area type="monotone" dataKey="bhayandarWest" name="Bhayandar West" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorBhayandar)" />
              <Area type="monotone" dataKey="highwayWEH" name="WEH Corridor" stroke="#f43f5e" strokeWidth={2} fillOpacity={1} fill="url(#colorWeh)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Legend notes */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs text-slate-600 border-t border-slate-100">
          <div className="p-3 bg-sky-50/70 rounded-xl border border-sky-100">
            <strong className="text-brand-900 block mb-0.5">🟢 6:00 AM - 8:30 AM (Golden Slot)</strong>
            Best for absolute beginners: Steering grip, gear switching, and straight line road sense with minimal traffic.
          </div>
          <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-100">
            <strong className="text-emerald-900 block mb-0.5">🟡 11:30 AM - 4:00 PM (Cruising Slot)</strong>
            Smooth suburban flow: Ideal for parallel parking, U-turns, and roundabout maneuvers near D-Mart & Maxus.
          </div>
          <div className="p-3 bg-rose-50/70 rounded-xl border border-rose-100">
            <strong className="text-rose-900 block mb-0.5">🔴 6:00 PM - 8:30 PM (Confidence Booster)</strong>
            Heavy bumper-to-bumper: For learners on Days 14-20 to master clutch biting point and aggressive auto-rickshaw anticipation.
          </div>
        </div>
      </div>

      {/* Interactive Hotspot Inspector & Clutch Strain Analyzer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Hotspot Directory */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900">
                Key Training Road Circuits & Junctions
              </h2>
              <p className="text-xs text-slate-500">
                Click any hotspot to view difficulty metrics and instructor advice.
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              <button
                onClick={() => setLocalityFilter('All')}
                className={`px-2.5 py-1 rounded-md font-bold transition whitespace-nowrap ${
                  localityFilter === 'All' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setLocalityFilter('Mira Road')}
                className={`px-2.5 py-1 rounded-md font-bold transition whitespace-nowrap ${
                  localityFilter === 'Mira Road' ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Mira Road
              </button>
              <button
                onClick={() => setLocalityFilter('Bhayandar')}
                className={`px-2.5 py-1 rounded-md font-bold transition whitespace-nowrap ${
                  localityFilter === 'Bhayandar' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Bhayandar
              </button>
              <button
                onClick={() => setLocalityFilter('Highway Corridor')}
                className={`px-2.5 py-1 rounded-md font-bold transition whitespace-nowrap ${
                  localityFilter === 'Highway Corridor' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                WEH Highway
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {filteredHotspots.map((item) => {
              const isSelected = selectedHotspot.id === item.id;
              let badgeColor = 'bg-emerald-100 text-emerald-800';
              if (item.congestionLevel === 'Moderate') badgeColor = 'bg-sky-100 text-sky-800';
              if (item.congestionLevel === 'Heavy') badgeColor = 'bg-amber-100 text-amber-800';
              if (item.congestionLevel === 'Critical') badgeColor = 'bg-rose-100 text-rose-800';

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedHotspot(item)}
                  className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between gap-4 ${
                    isSelected
                      ? 'border-brand-500 ring-2 ring-brand-500/20 bg-sky-50/40 shadow-sm'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${badgeColor}`}>
                        {item.congestionLevel} Congestion ({item.congestionScore}%)
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {item.locality}
                      </span>
                    </div>
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                      {item.name}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Ideal for: <strong className="text-slate-700">{item.recommendedSkillLevel}</strong>
                    </p>
                  </div>

                  <div className="text-right shrink-0 space-y-1">
                    <div className="text-xs font-black text-slate-700">
                      Difficulty: {'★'.repeat(item.difficultyRating)}{'☆'.repeat(5 - item.difficultyRating)}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Avg Speed: <strong>{item.avgSpeedKmh} km/h</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Deep Dive on Selected Hotspot */}
        <div className="lg:col-span-5">
          <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-7 shadow-xl border border-slate-800 sticky top-28 space-y-5">
            <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" /> Detailed Hotspot Diagnostic
                </span>
                <h3 className="text-lg font-black text-white mt-1">
                  {selectedHotspot.name}
                </h3>
                <p className="text-xs text-slate-400">
                  Sector: {selectedHotspot.locality} • Recommended for {selectedHotspot.recommendedSkillLevel}
                </p>
              </div>
              <div className="p-2.5 bg-slate-800 rounded-xl text-center shrink-0">
                <div className="text-xl font-black text-amber-400">{selectedHotspot.congestionScore}/100</div>
                <div className="text-[10px] text-slate-400 uppercase">Stress Score</div>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Best Learning Window</span>
                <span className="font-semibold text-emerald-400">{selectedHotspot.bestTrainingWindow}</span>
              </div>
              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Clutch Strain Level</span>
                <span className={`font-semibold ${selectedHotspot.clutchStrainIndex === 'Severe' ? 'text-rose-400' : 'text-amber-400'}`}>
                  {selectedHotspot.clutchStrainIndex} (Manual)
                </span>
              </div>
            </div>

            {/* Hazards List */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                Key Road Hazards on This Circuit:
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {selectedHotspot.keyHazards.map((hazard, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-rose-400 mt-0.5">•</span>
                    <span>{hazard}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructor Tip */}
            <div className="p-4 bg-brand-950/70 border border-brand-800/80 rounded-xl space-y-1 text-xs">
              <strong className="text-sky-300 flex items-center gap-1 font-bold">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Shitla Instructor Advice:
              </strong>
              <p className="text-slate-200 leading-relaxed italic">
                "{selectedHotspot.instructorTip}"
              </p>
            </div>

            {/* Direct Booking CTA */}
            <button
              onClick={() => onOpenBooking()}
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition flex items-center justify-center gap-2"
            >
              <span>Book Practice Session on This Circuit</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* AI Driving Route Planner (Gemini Powered) */}
      <div className="bg-gradient-to-r from-slate-900 via-brand-950 to-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-xl space-y-6">
        <div className="max-w-2xl space-y-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-900/90 border border-brand-700 text-amber-400 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" /> AI Route & Progression Strategist
          </span>
          <h2 className="text-2xl sm:text-3xl font-black">
            Get Your Personalized Mira-Bhayandar Road Training Itinerary
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Select your confidence level and car transmission to generate an optimized, low-anxiety road training sequence.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Your Current Driving Experience
            </label>
            <select
              value={learnerConfidence}
              onChange={(e: any) => setLearnerConfidence(e.target.value)}
              className="w-full text-xs sm:text-sm p-3 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="beginner">Complete Beginner (Never held a steering wheel)</option>
              <option value="nervous">Nervous Learner (Fear of heavy traffic & flyovers)</option>
              <option value="intermediate">Intermediate (Knows basics, struggles with parking)</option>
              <option value="experienced">License Holder (Needs Western Express Highway refresher)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Target Transmission
            </label>
            <select
              value={preferredTransmission}
              onChange={(e: any) => setPreferredTransmission(e.target.value)}
              className="w-full text-xs sm:text-sm p-3 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="manual">Manual Transmission (Maruti Swift Dual-Control)</option>
              <option value="automatic">Automatic AMT/CVT (Stress-free Mumbai commuting)</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleGenerateRouteAdvice}
              disabled={aiGenerating}
              className="w-full py-3 bg-amber-400 hover:bg-amber-300 disabled:bg-slate-700 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-2 shadow-lg"
            >
              {aiGenerating ? (
                <span>Generating Route Plan...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Analyze Traffic & Build Plan</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* AI Result Box */}
        {aiAdvice && (
          <div className="mt-4 p-6 bg-slate-800/90 border border-amber-400/40 rounded-2xl space-y-3">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4" /> Custom Shitla Road Progression Plan
            </div>
            <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line font-sans">
              {aiAdvice}
            </div>
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onOpenBooking()}
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs rounded-lg transition"
              >
                Enroll in This Recommended Track
              </button>
              <button
                onClick={onOpenAdvisor}
                className="px-5 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-xs rounded-lg transition"
              >
                Ask More Questions to AI Coach
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Local SEO & Search Traffic Transparency */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-4">
        <div>
          <span className="text-xs font-bold text-brand-600 uppercase tracking-widest">
            Local Authority & Organic Dominance
          </span>
          <h3 className="text-lg sm:text-xl font-black text-slate-900 mt-1">
            Mira-Bhayandar Search Demand & Driver Flow
          </h3>
          <p className="text-xs text-slate-500">
            Why thousands of residents trust Shitla Motor Training for their Thane RTO (MH-04) licensing:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          {LOCAL_SEARCH_TRAFFIC_STATS.map((stat, i) => (
            <div key={i} className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
              <div className="text-xs font-bold text-slate-800">{stat.keyword}</div>
              <div className="flex items-center justify-between text-[11px] pt-1">
                <span className="text-slate-500">{stat.monthlySearches} searches / mo</span>
                <span className="font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {stat.rankStatus}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
