import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Car, 
  MapPin, 
  Star, 
  CheckCircle, 
  Award, 
  Calendar, 
  Phone, 
  Users, 
  Clock, 
  HelpCircle, 
  ArrowRight,
  Sparkles,
  ChevronRight,
  Flame,
  Check,
  Compass,
  Gauge
} from 'lucide-react';
import { BRANCHES_DATA, COURSES_DATA, FAQ_DATA } from '../data/contentData';

interface HomePageProps {
  onNavigate: (page: string) => void;
  onOpenBooking: (courseId?: string, branchId?: string) => void;
  onOpenQuiz: () => void;
  onOpenAdvisor: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenBooking,
  onOpenQuiz,
  onOpenAdvisor,
}) => {
  const [selectedLocalityTab, setSelectedLocalityTab] = useState<'all' | 'mira-road' | 'bhayandar'>('all');

  const filteredBranches = BRANCHES_DATA.filter((branch) => {
    if (selectedLocalityTab === 'all') return true;
    return branch.locality === selectedLocalityTab;
  });

  return (
    <div className="space-y-16 pb-12">

      {/* Hero Section with Local SEO Keywords */}
      <section className="relative bg-gradient-to-br from-slate-950 via-slate-900 to-brand-950 text-white pt-12 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Glow ambient background elements */}
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-brand-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800/90 border border-slate-700 text-xs font-semibold text-amber-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Govt. Recognized Motor Driving School • MH-04 Thane RTO</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
                Learn Driving With Confidence in{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-300 to-sky-400">
                  Mira Road & Bhayandar
                </span>
              </h1>

              <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
                Join Thane’s highest-rated driving academy. Dual-control AC hatchbacks & sedans, certified patient male & female instructors, doorstep pickup, and hassle-free RTO Learner’s & Permanent License issuance.
              </p>

              {/* Trust Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-2.5 text-center">
                  <div className="text-xl font-black text-amber-400">25,000+</div>
                  <div className="text-[11px] text-slate-400">Trained Drivers</div>
                </div>
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-2.5 text-center">
                  <div className="text-xl font-black text-emerald-400">98.4%</div>
                  <div className="text-[11px] text-slate-400">1st Try RTO Pass</div>
                </div>
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-2.5 text-center">
                  <div className="text-xl font-black text-sky-400">4 Branches</div>
                  <div className="text-[11px] text-slate-400">In Mira-Bhayandar</div>
                </div>
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-2.5 text-center">
                  <div className="text-xl font-black text-rose-400">4.9 ★</div>
                  <div className="text-[11px] text-slate-400">Google Rating</div>
                </div>
              </div>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => onOpenBooking()}
                  className="px-6 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-sm uppercase tracking-wider rounded-xl shadow-xl shadow-amber-500/20 transition transform active:scale-95 flex items-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book Trial Driving Slot</span>
                </button>
                <button
                  onClick={() => onNavigate('traffic-analysis')}
                  className="px-5 py-3.5 bg-brand-700 hover:bg-brand-600 border border-brand-500 text-white font-bold text-sm rounded-xl transition flex items-center gap-2 shadow-lg shadow-sky-900/30"
                >
                  <Compass className="w-4 h-4 text-amber-300" />
                  <span>Mira-Bhayandar Traffic Analysis</span>
                </button>
                <button
                  onClick={onOpenQuiz}
                  className="px-5 py-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-sm rounded-xl transition flex items-center gap-2"
                >
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>RTO Mock Test</span>
                </button>
              </div>

              {/* Localities covered ticker */}
              <div className="pt-2 text-xs text-slate-400 flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-slate-300">Popular Pickups:</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded">Shanti Nagar</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded">Maxus Mall 150ft</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded">Kanakia</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded">Beverly Park</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded">Navghar</span>
              </div>

            </div>

            {/* Right Card / Interactive Fast Booking Widget */}
            <div className="lg:col-span-5">
              <div className="bg-white text-slate-900 rounded-2xl shadow-2xl p-6 border border-slate-200 relative">
                <div className="absolute -top-3 right-5 bg-gradient-to-r from-rose-600 to-amber-600 text-white text-[11px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow-md flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5" /> Early Bird 2025 Discount
                </div>

                <h3 className="text-lg font-black text-slate-900">
                  Instant Admission Enquiry
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  Check available batch timings & door pickup in your area
                </p>

                <div className="space-y-3 text-xs sm:text-sm">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Choose Your Preferred Course:
                    </label>
                    <select 
                      id="hero-course-select"
                      className="w-full text-xs sm:text-sm p-2.5 border border-slate-300 rounded-lg bg-slate-50 focus:ring-2 focus:ring-brand-500 outline-none"
                    >
                      {COURSES_DATA.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.title} — ₹{c.price.toLocaleString()}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Nearest Branch / Area:
                    </label>
                    <select 
                      id="hero-branch-select"
                      className="w-full text-xs sm:text-sm p-2.5 border border-slate-300 rounded-lg bg-slate-50 focus:ring-2 focus:ring-brand-500 outline-none"
                    >
                      {BRANCHES_DATA.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.subArea} ({b.locality === 'mira-road' ? 'Mira Road' : 'Bhayandar'})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1.5 text-xs text-amber-900">
                    <div className="font-bold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      What is Included in Your Training Package:
                    </div>
                    <ul className="space-y-1 text-[11px] text-amber-800">
                      <li>✔ Complete RTO Thane (MH-04) Paperwork & Test Slot</li>
                      <li>✔ Dual-Control AC Training Hatchback / Sedan</li>
                      <li>✔ Choice of Lady Trainer or Senior Coach</li>
                      <li>✔ Simulator training & parking track drill</li>
                    </ul>
                  </div>

                  <button
                    onClick={() => {
                      const courseEl = document.getElementById('hero-course-select') as HTMLSelectElement;
                      const branchEl = document.getElementById('hero-branch-select') as HTMLSelectElement;
                      onOpenBooking(courseEl?.value, branchEl?.value);
                    }}
                    className="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm uppercase tracking-wide rounded-xl shadow-lg transition transform active:scale-95 flex items-center justify-center gap-2"
                  >
                    <span>Check Batch Availability</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="flex items-center justify-center gap-2 text-slate-500 text-[11px] pt-1">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Or call head office: <strong>+91 98205 12341</strong></span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Traffic Feature Callout Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-sky-900 via-brand-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl border border-sky-800/60">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <Compass className="w-4 h-4" /> Real-Time Traffic & Route Intelligence
            </div>
            <h3 className="text-xl sm:text-2xl font-black">
              Scientific Training On Real Mira-Bhayandar Roads
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              We monitor hourly traffic at Kashimira Junction, Maxus Mall 150ft Road, and Shanti Nagar so you practice clutch control and parking at the ideal congestion levels.
            </p>
          </div>
          <button
            onClick={() => onNavigate('traffic-analysis')}
            className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-2 shrink-0 shadow-lg"
          >
            <span>Explore Traffic Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Why Choose Shitla Motors Feature Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <h2 className="text-xs font-bold text-brand-600 uppercase tracking-widest">
            The Shitla Driving Advantage
          </h2>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            Why 9 out of 10 Mira-Bhayandar Residents Recommend Us
          </p>
          <p className="text-sm text-slate-600">
            We don't just help you pass the RTO test; we train you for real Mumbai traffic, highway speed control, and narrow colony parking.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition">
            <div className="w-12 h-12 bg-sky-100 text-sky-700 rounded-xl flex items-center justify-center mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2">
              Govt. Dual-Control Cars
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every training vehicle is equipped with auxiliary dual clutch and brake controls for maximum learner safety on busy Mira Road streets.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition">
            <div className="w-12 h-12 bg-rose-100 text-rose-700 rounded-xl flex items-center justify-center mb-4">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2">
              Certified Lady Instructors
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Patient, certified female driving mentors specially designated for lady learners in both Mira Road East and Bhayandar West.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition">
            <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center mb-4">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2">
              Thane MH-04 RTO Escort
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              End-to-end assistance: online appointment booking, biometric test, driving track rehearsal, and doorstep license delivery.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-xl flex items-center justify-center mb-4">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2">
              6 AM to 9 PM Daily Batches
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Working professionals can pick early morning 6 AM slots before local train commute or relaxed weekend special coaching.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Packages & Courses */}
      <section className="bg-slate-100/70 py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
                Transparent Pricing
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Popular Driving Packages in Mira Road & Bhayandar
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                No hidden costs. All packages include fuel, trainer fee, and vehicle maintenance.
              </p>
            </div>

            <button
              onClick={() => onNavigate('services')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-brand-600 hover:text-brand-700 self-start md:self-auto"
            >
              <span>View All 5 Courses & Syllabuses</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {COURSES_DATA.slice(0, 3).map((course) => (
              <div
                key={course.id}
                className={`bg-white rounded-2xl p-6 border transition flex flex-col justify-between relative shadow-sm hover:shadow-md ${
                  course.popular ? 'border-brand-500 ring-2 ring-brand-500/20' : 'border-slate-200'
                }`}
              >
                {course.popular && (
                  <div className="absolute -top-3 left-6 bg-brand-600 text-white text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full">
                    Most Enrolled
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500 mb-2">
                    <span className="font-semibold text-brand-700 bg-sky-50 px-2 py-0.5 rounded">
                      {course.transmission} Car
                    </span>
                    <span>{course.durationDays} Days ({course.sessionMinutes} mins/day)</span>
                  </div>

                  <h3 className="font-black text-slate-900 text-lg mb-3">
                    {course.title}
                  </h3>

                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-2xl font-black text-slate-900">
                      ₹{course.price.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400 line-through">
                      ₹{course.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                      Save ₹{(course.originalPrice - course.price).toLocaleString()}
                    </span>
                  </div>

                  <ul className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-4 mb-6">
                    {course.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => onOpenBooking(course.id)}
                  className="w-full py-2.5 bg-slate-900 hover:bg-brand-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition"
                >
                  Book Admission in This Batch
                </button>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Local Branch Directory Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
            Convenient Local Centers
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Shitla Motor Training School Branches
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Visit your nearest branch office or request a trainer pickup directly from your residential apartment complex.
          </p>

          {/* Locality Tab Buttons */}
          <div className="flex items-center justify-center gap-2 pt-3">
            <button
              onClick={() => setSelectedLocalityTab('all')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
                selectedLocalityTab === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
              }`}
            >
              All 4 Branches
            </button>
            <button
              onClick={() => setSelectedLocalityTab('mira-road')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
                selectedLocalityTab === 'mira-road'
                  ? 'bg-brand-600 text-white'
                  : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
              }`}
            >
              Mira Road (Station & Kanakia)
            </button>
            <button
              onClick={() => setSelectedLocalityTab('bhayandar')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
                selectedLocalityTab === 'bhayandar'
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
              }`}
            >
              Bhayandar (Maxus & Navghar)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredBranches.map((branch) => (
            <div
              key={branch.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition space-y-4"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-brand-600 mb-1">
                    <MapPin className="w-3.5 h-3.5" />
                    <span className="uppercase tracking-wide">{branch.subArea}</span>
                  </div>
                  <h3 className="font-black text-slate-900 text-base sm:text-lg">
                    {branch.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Landmark: <strong>{branch.landmark}</strong>
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <div className="inline-flex items-center gap-1 bg-amber-50 text-amber-900 text-xs font-black px-2 py-1 rounded-md border border-amber-200">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    <span>{branch.rating}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">({branch.reviewsCount} Google Reviews)</div>
                </div>
              </div>

              <div className="text-xs text-slate-600 space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <p><strong>Address:</strong> {branch.address}</p>
                <p><strong>Hours:</strong> {branch.timing}</p>
                <p><strong>Pickup Localities:</strong> {branch.pickupPoints.join(', ')}</p>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <a
                  href={`tel:${branch.phone}`}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg flex items-center gap-1.5 transition"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-600" /> Call Branch
                </a>
                <a
                  href={`https://wa.me/${branch.whatsapp}?text=Hi,%20I%20want%20to%20inquire%20about%20driving%20classes%20at%20${encodeURIComponent(branch.subArea)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-lg flex items-center gap-1.5 transition"
                >
                  WhatsApp Branch
                </a>
                <button
                  onClick={() => onOpenBooking(undefined, branch.id)}
                  className="ml-auto px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold rounded-lg transition"
                >
                  Book Here
                </button>
              </div>
            </div>
          ))}
        </div>

      </section>

      {/* RTO Test Banner CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-slate-900 via-brand-950 to-slate-900 rounded-3xl p-8 sm:p-10 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl border border-slate-800">
          <div className="space-y-2 max-w-xl">
            <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-amber-400">
              <Award className="w-4 h-4" /> Maharashtra RTO Computer Exam Prep
            </span>
            <h3 className="text-2xl sm:text-3xl font-black">
              Test Your Driving Rules & Signage IQ
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Take our interactive 5-question mock test curated directly from official Thane MH-04 question banks. Instant results and explanations.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 shrink-0">
            <button
              onClick={onOpenQuiz}
              className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition"
            >
              Start Free Quiz Now
            </button>
            <button
              onClick={() => onNavigate('rto-guide')}
              className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition"
            >
              Read RTO MH-04 Guide
            </button>
          </div>
        </div>
      </section>

      {/* Real Local Testimonials */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
            Real Student Experiences
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Stories from Mira-Bhayandar Drivers
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Verified reviews from neighborhood residents in Shanti Nagar, Maxus Mall area, Kanakia, and Jesal Park.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed">
              "I live in Kanakia Road, Mira Road East. I was terrified of Mumbai bumper-to-bumper traffic. Instructor Ramesh sir taught me clutch balancing on the flyover and now I commute daily to Andheri in my Swift without fear!"
            </p>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900">Pooja Nair</span>
              <span className="text-slate-400">Kanakia, Mira Road</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed">
              "Best experience at Bhayandar West branch near Maxus Mall! The lady trainer Mrs. Sunita was so patient. Got my permanent driving smart card delivered right to my apartment within 35 days."
            </p>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900">Snehal Shah</span>
              <span className="text-slate-400">150ft Road, Bhayandar W</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed">
              "Opted for the 4-Wheeler Automatic package. Extremely helpful for Western Express Highway driving. Dual control cars are well-maintained with chilled AC. Highly recommended!"
            </p>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900">Farhan Merchant</span>
              <span className="text-slate-400">Shanti Nagar Sector 4</span>
            </div>
          </div>
        </div>

      </section>

      {/* Quick FAQ Strip */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-slate-900 text-lg">
              Frequently Asked Questions (Mira-Bhayandar)
            </h3>
            <button
              onClick={() => onNavigate('faq')}
              className="text-xs font-bold text-brand-600 hover:underline"
            >
              View All FAQs
            </button>
          </div>
          <div className="space-y-3 text-xs sm:text-sm divide-y divide-slate-100">
            {FAQ_DATA.slice(0, 3).map((item, idx) => (
              <div key={idx} className="pt-3 first:pt-0 space-y-1">
                <p className="font-bold text-slate-800">Q: {item.question}</p>
                <p className="text-slate-600 text-xs leading-relaxed">{item.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
};
