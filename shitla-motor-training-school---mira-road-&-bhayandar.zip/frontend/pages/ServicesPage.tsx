import React, { useState } from 'react';
import { 
  Car, 
  CheckCircle, 
  Clock, 
  Calendar, 
  ShieldCheck, 
  Fuel, 
  Sparkles, 
  ArrowRight,
  Sliders,
  DollarSign
} from 'lucide-react';
import { COURSES_DATA } from '../data/contentData';

interface ServicesPageProps {
  onOpenBooking: (courseId?: string) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onOpenBooking }) => {
  const [filter, setFilter] = useState<'all' | 'four-wheeler' | 'two-wheeler' | 'refresher'>('all');

  const filteredCourses = COURSES_DATA.filter((course) => {
    if (filter === 'all') return true;
    if (filter === 'four-wheeler') return course.category === 'four-wheeler' || course.category === 'combo';
    if (filter === 'two-wheeler') return course.category === 'two-wheeler' || course.category === 'combo';
    if (filter === 'refresher') return course.category === 'refresher';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Header */}
      <div className="max-w-3xl mx-auto text-center space-y-3">
        <span className="text-xs font-bold text-brand-600 uppercase tracking-widest bg-sky-50 px-3 py-1 rounded-full border border-sky-100">
          Certified Training Syllabuses
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
          Motor Driving Courses & Fees in Mira Road & Bhayandar
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Choose from beginner manual hatchbacks, automatic city cruising, two-wheeler scooty/bike balancing, or confidence-booster highway refreshers.
        </p>

        {/* Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filter === 'all'
                ? 'bg-slate-900 text-white shadow'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            All Packages
          </button>
          <button
            onClick={() => setFilter('four-wheeler')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filter === 'four-wheeler'
                ? 'bg-brand-600 text-white shadow'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            4-Wheeler (Manual & Auto)
          </button>
          <button
            onClick={() => setFilter('two-wheeler')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filter === 'two-wheeler'
                ? 'bg-amber-500 text-slate-950 shadow'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            2-Wheeler (Bike / Activa)
          </button>
          <button
            onClick={() => setFilter('refresher')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              filter === 'refresher'
                ? 'bg-emerald-600 text-white shadow'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Refresher (Own Car / Highway)
          </button>
        </div>
      </div>

      {/* Courses Detailed Cards */}
      <div className="space-y-8">
        {filteredCourses.map((course) => (
          <div
            key={course.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition overflow-hidden grid grid-cols-1 lg:grid-cols-12"
          >
            {/* Left summary column */}
            <div className="lg:col-span-5 p-6 sm:p-8 bg-slate-50 border-r border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-black uppercase tracking-wider bg-brand-100 text-brand-800 px-2 py-0.5 rounded">
                    {course.transmission} Transmission
                  </span>
                  {course.rtoAssistanceIncluded && (
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> RTO License Included
                    </span>
                  )}
                </div>

                <h2 className="text-xl sm:text-2xl font-black text-slate-900 mb-2">
                  {course.title}
                </h2>

                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-3xl font-black text-brand-700">
                    ₹{course.price.toLocaleString()}
                  </span>
                  <span className="text-sm text-slate-400 line-through">
                    ₹{course.originalPrice.toLocaleString()}
                  </span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Save ₹{(course.originalPrice - course.price).toLocaleString()}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 mb-6">
                  <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Duration</span>
                    <span className="font-bold text-slate-800">{course.durationDays} Days Course</span>
                  </div>
                  <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Daily Session</span>
                    <span className="font-bold text-slate-800">{course.sessionMinutes} Minutes Daily</span>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Package Highlights:
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {course.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <button
                onClick={() => onOpenBooking(course.id)}
                className="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition flex items-center justify-center gap-2"
              >
                <span>Book This Course</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Right syllabus breakdown */}
            <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  Day-by-Day Practical Driving Curriculum
                </h3>

                <div className="space-y-3">
                  {course.syllabus.map((item, index) => (
                    <div
                      key={index}
                      className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-sky-50/50 hover:border-sky-200 transition text-xs sm:text-sm text-slate-700 flex items-start gap-3"
                    >
                      <div className="w-6 h-6 rounded-full bg-brand-100 text-brand-800 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {index + 1}
                      </div>
                      <div className="leading-snug">{item}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
                <span>📍 Available at: Mira Road East, Kanakia, Bhayandar West & Navghar</span>
                <span className="font-semibold text-emerald-600">Zero Extra Charge for AC</span>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Doorstep Pickup Guarantee Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="font-black text-amber-950 text-base sm:text-lg">
            Free Doorstep Pickup Across Mira-Bhayandar
          </h4>
          <p className="text-xs sm:text-sm text-amber-800 mt-1 max-w-2xl">
            We pick you up from your building gate in Shanti Nagar, Kanakia, Beverly Park, Poonam Sagar, Jangid Enclave, Jesal Park, or Maxus Mall 150ft road.
          </p>
        </div>
        <button
          onClick={() => onOpenBooking()}
          className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shrink-0 transition"
        >
          Check My Society Pickup
        </button>
      </div>

    </div>
  );
};
