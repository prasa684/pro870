import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Search, Code, ShieldCheck } from 'lucide-react';
import { FAQ_DATA } from '../data/contentData';

interface FaqPageProps {
  onOpenSchema: () => void;
  onOpenAdvisor: () => void;
}

export const FaqPage: React.FC<FaqPageProps> = ({ onOpenSchema, onOpenAdvisor }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Admission & Fees', 'RTO License (MH-04)', 'Training & Car Types', 'Safety & Ladies Special'];

  const filteredFaqs = FAQ_DATA.filter((faq) => {
    const matchesSearch = 
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      
      {/* Title */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold text-brand-600 uppercase tracking-widest bg-sky-50 px-3 py-1 rounded-full border border-sky-100">
          Knowledge Base & Local Schema
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
          Frequently Asked Questions
        </h1>
        <p className="text-sm text-slate-600">
          Clear answers about admission rules, fees, Thane RTO licenses, and driving batches in Mira Road & Bhayandar.
        </p>
      </div>

      {/* Search & Schema Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search questions (e.g. lady instructor, Thane RTO, automatic car)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs sm:text-sm pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
          />
        </div>

        <button
          onClick={onOpenSchema}
          className="w-full sm:w-auto px-4 py-3 bg-slate-900 hover:bg-slate-800 text-amber-400 text-xs font-bold rounded-xl flex items-center justify-center gap-2 shrink-0 transition"
        >
          <Code className="w-4 h-4" />
          <span>Inspect Google FAQ Schema (JSON-LD)</span>
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full font-semibold transition whitespace-nowrap ${
              activeCategory === cat
                ? 'bg-brand-600 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* FAQ Accordion List */}
      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-2xl border border-slate-200">
            <p className="text-slate-500 text-sm">No matching questions found.</p>
            <button
              onClick={onOpenAdvisor}
              className="mt-3 text-xs text-brand-600 font-bold hover:underline"
            >
              Ask our AI Driving Advisor instead
            </button>
          </div>
        ) : (
          filteredFaqs.map((faq, idx) => {
            const isExpanded = expandedIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden transition shadow-sm"
              >
                <button
                  onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-slate-900 text-sm sm:text-base hover:text-brand-600 transition"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-sky-100 text-brand-700 font-black text-xs flex items-center justify-center shrink-0">
                      ?
                    </span>
                    <span>{faq.question}</span>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                  )}
                </button>

                {isExpanded && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    <p>{faq.answer}</p>
                    <div className="mt-3 pt-2 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-50">
                      <span>Category: <strong>{faq.category}</strong></span>
                      <span className="text-emerald-600">✓ Verified by Shitla Motor Training</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Still have questions */}
      <div className="bg-slate-100 rounded-2xl p-6 text-center space-y-3">
        <h3 className="font-bold text-slate-900 text-sm sm:text-base">
          Have a specific question about your location in Mira-Bhayandar?
        </h3>
        <p className="text-xs text-slate-600 max-w-md mx-auto">
          Our senior instructors are available 7 days a week to clarify documentation, fees, or doorstep pickup options.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
          <a
            href="tel:+919820512341"
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition"
          >
            Call +91 98205 12341
          </a>
          <button
            onClick={onOpenAdvisor}
            className="px-5 py-2 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold rounded-xl transition"
          >
            Ask Virtual AI Counselor
          </button>
        </div>
      </div>

    </div>
  );
};
