import React from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Star, 
  Navigation, 
  ShieldCheck, 
  MessageCircle,
  ExternalLink
} from 'lucide-react';
import { BRANCHES_DATA } from '../data/contentData';

interface BranchesPageProps {
  onOpenBooking: (courseId?: string, branchId?: string) => void;
}

export const BranchesPage: React.FC<BranchesPageProps> = ({ onOpenBooking }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Title */}
      <div className="max-w-3xl mx-auto text-center space-y-3">
        <span className="text-xs font-bold text-brand-600 uppercase tracking-widest bg-sky-50 px-3 py-1 rounded-full border border-sky-100">
          Local Presence in Mira-Bhayandar
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
          Shitla Motor Training School Branch Directory
        </h1>
        <p className="text-sm sm:text-base text-slate-600">
          Walk into any of our 4 centers across Mira Road and Bhayandar for in-person document verification, simulator trials, or batch scheduling.
        </p>
      </div>

      {/* Branches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {BRANCHES_DATA.map((branch) => (
          <div
            key={branch.id}
            className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between"
          >
            {/* Header with Visual Tag */}
            <div className="p-6 sm:p-7 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-xs font-black uppercase tracking-wider bg-brand-50 text-brand-700 px-2.5 py-1 rounded-md border border-brand-200">
                    {branch.locality === 'mira-road' ? 'Mira Road Jurisdiction' : 'Bhayandar Jurisdiction'}
                  </span>
                  <h2 className="text-xl font-black text-slate-900 mt-2">
                    {branch.name}
                  </h2>
                </div>
                <div className="text-right shrink-0">
                  <div className="flex items-center gap-1 text-amber-500 font-black text-sm bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                    <Star className="w-4 h-4 fill-amber-400" />
                    <span>{branch.rating}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {branch.reviewsCount} Google Reviews
                  </span>
                </div>
              </div>

              {/* Address details */}
              <div className="space-y-2 text-xs sm:text-sm text-slate-600">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                  <span><strong>Address:</strong> {branch.address}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Navigation className="w-4 h-4 text-sky-500 shrink-0" />
                  <span><strong>Landmark:</strong> {branch.landmark}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>Operational Hours:</strong> {branch.timing}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span><strong>RTO Jurisdiction:</strong> {branch.rtoZone}</span>
                </div>
              </div>

              {/* Pickup points list */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
                  Covered Pickup Localities:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {branch.pickupPoints.map((pt, i) => (
                    <span
                      key={i}
                      className="bg-white border border-slate-200 text-slate-700 text-[11px] px-2 py-0.5 rounded-md font-medium"
                    >
                      {pt}
                    </span>
                  ))}
                </div>
              </div>

              {/* Branch Features */}
              <div className="space-y-1">
                {branch.features.map((feat, i) => (
                  <div key={i} className="text-xs text-slate-500 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-500 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions Bar */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <a
                  href={`tel:${branch.phone}`}
                  className="px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-bold rounded-lg flex items-center gap-1.5 transition"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{branch.phone}</span>
                </a>
                <a
                  href={`https://wa.me/${branch.whatsapp}?text=Hi,%20I%20want%20to%20visit%20the%20${encodeURIComponent(branch.subArea)}%20branch.`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>

              <button
                onClick={() => onOpenBooking(undefined, branch.id)}
                className="px-4 py-2 bg-slate-900 hover:bg-brand-600 text-white text-xs font-bold rounded-lg transition"
              >
                Book at This Branch
              </button>
            </div>

          </div>
        ))}
      </div>

      {/* RTO Jurisdiction Info Note */}
      <div className="bg-sky-50 border border-sky-200 rounded-2xl p-6 sm:p-8 flex items-start gap-4">
        <ShieldCheck className="w-6 h-6 text-brand-600 shrink-0 mt-1" />
        <div className="space-y-1">
          <h3 className="font-bold text-slate-900 text-sm sm:text-base">
            Thane RTO (MH-04) Jurisdiction Note for Mira-Bhayandar Applicants
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            All residents holding Aadhaar cards or rental registered agreements within Mira Road East/West and Bhayandar East/West are processed officially under the Thane Regional Transport Office (MH-04). Shitla Motor Training provides our dedicated training vehicles at the RTO test ground on your test day so you don't face unfamiliar pedals.
          </p>
        </div>
      </div>

    </div>
  );
};
