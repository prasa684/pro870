import React from 'react';
import { 
  FileText, 
  ShieldCheck, 
  Award, 
  CheckCircle2, 
  HelpCircle, 
  AlertCircle, 
  Calendar,
  ExternalLink
} from 'lucide-react';

interface RtoGuidePageProps {
  onOpenQuiz: () => void;
  onOpenBooking: () => void;
}

export const RtoGuidePage: React.FC<RtoGuidePageProps> = ({ onOpenQuiz, onOpenBooking }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold text-brand-600 uppercase tracking-widest bg-sky-50 px-3 py-1 rounded-full border border-sky-100">
          Official Government Procedure Guide
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
          Thane RTO (MH-04) Driving License Guide
        </h1>
        <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
          Everything Mira Road and Bhayandar residents need to know about getting a Learner’s License (LL) and Permanent Driving License (DL).
        </p>
      </div>

      {/* 4-Step Process Timeline */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <h2 className="text-lg font-black text-slate-900 border-b border-slate-100 pb-3">
          Step-by-Step RTO Licensing Roadmap
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-2">
            <div className="w-9 h-9 rounded-full bg-brand-600 text-white font-black text-sm flex items-center justify-center">
              1
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Document Verification</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Submit Aadhaar, address proof in Mira-Bhayandar, 3 photos, and age proof (PAN/10th certificate).
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-9 h-9 rounded-full bg-brand-600 text-white font-black text-sm flex items-center justify-center">
              2
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Learner’s License (LL)</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Clear the computer-based traffic sign test. LL is issued online within 24-48 hours with 6 months validity.
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-9 h-9 rounded-full bg-brand-600 text-white font-black text-sm flex items-center justify-center">
              3
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Practical Training</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Complete your 15-20 days training with Shitla Motors on road traffic, reverse parking, and H-shape tracks.
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-9 h-9 rounded-full bg-emerald-600 text-white font-black text-sm flex items-center justify-center">
              4
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Permanent DL Test</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Appear for the official driving test on Thane RTO ground. Smart Card DL is dispatched to your residence.
            </p>
          </div>
        </div>
      </div>

      {/* Documents Required Checklist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <FileText className="w-5 h-5 text-brand-600" />
            Mandatory Documents Required
          </h3>
          <ul className="space-y-2 text-xs sm:text-sm text-slate-600">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Aadhaar Card:</strong> Must have updated mobile number linked for Sarathi OTP.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Age Proof:</strong> Birth Certificate, School Leaving Certificate, or PAN Card.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Address Proof:</strong> Electricity bill, Registered Rent Agreement, or Voter ID.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Photographs:</strong> 3 recent passport-size photos with clear background.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Medical Certificate (Form 1A):</strong> Required for candidates aged 40+ or transport category.</span>
            </li>
          </ul>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-amber-500" />
            Eligibility & Age Criteria
          </h3>
          <div className="space-y-2 text-xs sm:text-sm text-slate-600">
            <p><strong>16 Years:</strong> Eligible for gearless motorcycle/scooter up to 50cc (e.g. Electric/Scooty).</p>
            <p><strong>18 Years:</strong> Eligible for private Light Motor Vehicles (LMV Cars) & Geared Motorcycles (MCWG).</p>
            <p><strong>20 Years:</strong> Eligible for Transport & Commercial vehicles (Yellow plate taxis/autos).</p>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 mt-2">
              💡 <strong>Shitla Motors Tip:</strong> We provide free online Form-1, Form-2, and Sarathi Parivahan portal upload assistance at all our Mira-Bhayandar centers.
            </div>
          </div>
        </div>
      </div>

      {/* Quiz Call to action */}
      <div className="bg-slate-900 rounded-2xl p-8 text-white text-center space-y-4">
        <h3 className="text-xl sm:text-2xl font-black">
          Prepare for the Thane RTO Computer Screen Test
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto">
          Pass on your very first try! Try our quick mock test with official questions regarding mandatory signs, cautionary signs, and right of way.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={onOpenQuiz}
            className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition"
          >
            Launch Mock RTO Test
          </button>
          <button
            onClick={() => onOpenBooking()}
            className="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl transition"
          >
            Book Driving School Admission
          </button>
        </div>
      </div>

    </div>
  );
};
