export interface Branch {
  id: string;
  name: string;
  locality: 'mira-road' | 'bhayandar';
  subArea: string;
  address: string;
  landmark: string;
  phone: string;
  whatsapp: string;
  email: string;
  timing: string;
  geo: {
    lat: number;
    lng: number;
  };
  pickupPoints: string[];
  features: string[];
  rating: number;
  reviewsCount: number;
  rtoZone: string;
}

export interface Course {
  id: string;
  title: string;
  category: 'four-wheeler' | 'two-wheeler' | 'combo' | 'refresher';
  transmission: 'Manual' | 'Automatic' | 'Both';
  durationDays: number;
  sessionMinutes: number;
  price: number;
  originalPrice: number;
  features: string[];
  syllabus: string[];
  rtoAssistanceIncluded: boolean;
  popular?: boolean;
}

export interface BookingFormData {
  fullName: string;
  phone: string;
  email: string;
  age: number;
  preferredBranchId: string;
  courseId: string;
  preferredSlot: 'Morning (6 AM - 10 AM)' | 'Afternoon (11 AM - 3 PM)' | 'Evening (4 PM - 8 PM)' | 'Weekend Special';
  preferredInstructor: 'Any' | 'Female Instructor' | 'Senior Instructor';
  pickupLocation: string;
  hasLearnerLicense: boolean;
  notes: string;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: 'Admission & Fees' | 'RTO License (MH-04)' | 'Training & Car Types' | 'Safety & Ladies Special';
}

export interface RTOQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  category: 'Traffic Sign' | 'Rules & Regulations' | 'Road Safety';
}

export interface TrafficHotspot {
  id: string;
  name: string;
  locality: 'Mira Road' | 'Bhayandar' | 'Highway Corridor';
  congestionLevel: 'Low' | 'Moderate' | 'Heavy' | 'Critical';
  congestionScore: number; // 0-100
  avgSpeedKmh: number;
  difficultyRating: 1 | 2 | 3 | 4 | 5;
  recommendedSkillLevel: 'Beginner (Day 1-5)' | 'Intermediate (Day 6-12)' | 'Advanced (Day 13-20)' | 'Refresher Only';
  bestTrainingWindow: string;
  keyHazards: string[];
  instructorTip: string;
  clutchStrainIndex: 'Low' | 'Medium' | 'High' | 'Severe';
}

export interface HourlyTrafficData {
  timeSlot: string;
  miraRoadEast: number;
  bhayandarWest: number;
  highwayWEH: number;
  recommendation: 'Ideal for Beginners' | 'Smooth Cruising' | 'Heavy Traffic Practice' | 'Extreme Stress Training';
}
