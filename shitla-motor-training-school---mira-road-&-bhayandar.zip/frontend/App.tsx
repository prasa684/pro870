import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { QuickBookModal } from './components/QuickBookModal';
import { LocalSchemaViewer } from './components/LocalSchemaViewer';
import { RtoQuizModal } from './components/RtoQuizModal';
import { GeminiAdvisorModal } from './components/GeminiAdvisorModal';
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { BranchesPage } from './pages/BranchesPage';
import { RtoGuidePage } from './pages/RtoGuidePage';
import { FaqPage } from './pages/FaqPage';
import { TrafficAnalysisPage } from './pages/TrafficAnalysisPage';

export const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingCourseId, setBookingCourseId] = useState<string | undefined>(undefined);
  const [bookingBranchId, setBookingBranchId] = useState<string | undefined>(undefined);
  
  const [isSchemaOpen, setIsSchemaOpen] = useState(false);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [isAdvisorOpen, setIsAdvisorOpen] = useState(false);

  // Scroll to top on page switch
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const handleOpenBooking = (courseId?: string, branchId?: string) => {
    setBookingCourseId(courseId);
    setBookingBranchId(branchId);
    setIsBookingOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-800">
      
      {/* Top Navigation */}
      <Navbar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAdvisor={() => setIsAdvisorOpen(true)}
      />

      {/* Main Page View */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={setCurrentPage}
            onOpenBooking={handleOpenBooking}
            onOpenQuiz={() => setIsQuizOpen(true)}
            onOpenAdvisor={() => setIsAdvisorOpen(true)}
          />
        )}

        {currentPage === 'traffic-analysis' && (
          <TrafficAnalysisPage
            onOpenBooking={handleOpenBooking}
            onOpenAdvisor={() => setIsAdvisorOpen(true)}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage onOpenBooking={handleOpenBooking} />
        )}

        {currentPage === 'branches' && (
          <BranchesPage onOpenBooking={handleOpenBooking} />
        )}

        {currentPage === 'rto-guide' && (
          <RtoGuidePage
            onOpenQuiz={() => setIsQuizOpen(true)}
            onOpenBooking={() => handleOpenBooking()}
          />
        )}

        {currentPage === 'faq' && (
          <FaqPage
            onOpenSchema={() => setIsSchemaOpen(true)}
            onOpenAdvisor={() => setIsAdvisorOpen(true)}
          />
        )}
      </main>

      {/* Sticky Bottom Bar for Mobile Call & Booking CTA */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200 px-4 py-2.5 flex items-center justify-between gap-3 shadow-lg">
        <a
          href="tel:+919820512341"
          className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-lg text-center flex items-center justify-center gap-1.5"
        >
          📞 Call Desk
        </a>
        <button
          onClick={() => setCurrentPage('traffic-analysis')}
          className="flex-1 py-2 bg-sky-100 hover:bg-sky-200 text-sky-900 font-bold text-xs rounded-lg text-center"
        >
          🚦 Traffic
        </button>
        <button
          onClick={() => handleOpenBooking()}
          className="flex-1 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-lg text-center"
        >
          Book Batch
        </button>
      </div>

      {/* Modals */}
      <QuickBookModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        preSelectedCourseId={bookingCourseId}
        preSelectedBranchId={bookingBranchId}
      />

      <LocalSchemaViewer
        isOpen={isSchemaOpen}
        onClose={() => setIsSchemaOpen(false)}
      />

      <RtoQuizModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        onOpenBooking={() => handleOpenBooking()}
      />

      <GeminiAdvisorModal
        isOpen={isAdvisorOpen}
        onClose={() => setIsAdvisorOpen(false)}
        onOpenBooking={() => handleOpenBooking()}
      />

      {/* Footer */}
      <Footer
        onNavigate={setCurrentPage}
        onOpenSchema={() => setIsSchemaOpen(true)}
      />

    </div>
  );
};
