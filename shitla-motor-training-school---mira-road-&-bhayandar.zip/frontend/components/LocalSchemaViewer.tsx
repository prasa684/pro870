import React, { useState } from 'react';
import { X, Code, Copy, Check, FileCheck, Search, Database } from 'lucide-react';
import { BRANCHES_DATA, FAQ_DATA } from '../data/contentData';

interface LocalSchemaViewerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LocalSchemaViewer: React.FC<LocalSchemaViewerProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [schemaType, setSchemaType] = useState<'drivingSchool' | 'faq' | 'breadcrumb'>('drivingSchool');

  if (!isOpen) return null;

  // Generate dynamic JSON-LD
  const drivingSchoolSchema = {
    "@context": "https://schema.org",
    "@type": "DrivingSchool",
    "@id": "https://shitlamotors.com/#organization",
    "name": "Shitla Motor Training School",
    "image": "https://shitlamotors.com/images/shitla-motor-training-mira-road.jpg",
    "telephone": "+91-9820512341",
    "email": "info@shitlamotors.com",
    "url": "https://shitlamotors.com",
    "priceRange": "₹3,499 - ₹8,999",
    "currenciesAccepted": "INR",
    "paymentAccepted": "Cash, Credit Card, UPI, Net Banking",
    "areaServed": [
      {
        "@type": "AdministrativeArea",
        "name": "Mira Road East"
      },
      {
        "@type": "AdministrativeArea",
        "name": "Mira Road West"
      },
      {
        "@type": "AdministrativeArea",
        "name": "Bhayandar East"
      },
      {
        "@type": "AdministrativeArea",
        "name": "Bhayandar West"
      },
      {
        "@type": "AdministrativeArea",
        "name": "Thane District (MH-04 RTO)"
      }
    ],
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Motor Driving & License Packages",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "4-Wheeler Manual Driving Course with RTO License",
            "description": "20 days comprehensive driving lessons on dual-control Maruti Swift in Mira Road & Bhayandar."
          },
          "price": "6499",
          "priceCurrency": "INR"
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "4-Wheeler Automatic (AMT/CVT) Car Driving Training",
            "description": "15 days automatic transmission coaching with focus on traffic management and highway skills."
          },
          "price": "7499",
          "priceCurrency": "INR"
        }
      ]
    },
    "department": BRANCHES_DATA.map((branch) => ({
      "@type": "LocalBusiness",
      "name": branch.name,
      "telephone": branch.phone,
      "address": {
        "@type": "PostalAddress",
        "streetAddress": branch.address,
        "addressLocality": branch.locality === 'mira-road' ? 'Mira Road' : 'Bhayandar',
        "addressRegion": "Maharashtra",
        "postalCode": branch.address.includes('401107') ? '401107' : branch.address.includes('401105') ? '401105' : '401101',
        "addressCountry": "IN"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": branch.geo.lat,
        "longitude": branch.geo.lng
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": branch.rating,
        "reviewCount": branch.reviewsCount,
        "bestRating": "5"
      }
    }))
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": FAQ_DATA.map((faq) => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://shitlamotors.com"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Mira Road Branches",
        "item": "https://shitlamotors.com/#branches"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "Bhayandar Driving Training",
        "item": "https://shitlamotors.com/#services"
      }
    ]
  };

  const currentJson = 
    schemaType === 'drivingSchool' 
      ? drivingSchoolSchema 
      : schemaType === 'faq' 
      ? faqSchema 
      : breadcrumbSchema;

  const jsonString = JSON.stringify(currentJson, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-base font-bold text-white">
                Live Google Local SEO Schema Generator
              </h3>
              <p className="text-xs text-slate-400">
                Validated JSON-LD schema ready for Google Rich Snippets & Local Map Pack
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2 px-5 py-3 bg-slate-900 border-b border-slate-800 text-xs">
          <button
            onClick={() => setSchemaType('drivingSchool')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              schemaType === 'drivingSchool'
                ? 'bg-brand-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            DrivingSchool & Multi-Location
          </button>
          <button
            onClick={() => setSchemaType('faq')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              schemaType === 'faq'
                ? 'bg-brand-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            FAQPage Schema
          </button>
          <button
            onClick={() => setSchemaType('breadcrumb')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              schemaType === 'breadcrumb'
                ? 'bg-brand-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            BreadcrumbList
          </button>
        </div>

        {/* Code Content */}
        <div className="relative flex-1 overflow-y-auto p-5 bg-slate-950 font-mono text-xs text-emerald-400 leading-relaxed">
          <button
            onClick={handleCopy}
            className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-sans transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Script'}</span>
          </button>
          <pre>{jsonString}</pre>
        </div>

        {/* SEO Note */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
          <span>✨ This markup matches Google guidelines for Thane MH-04 Regional Local SEO</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 text-slate-200 hover:bg-slate-700 rounded-lg text-xs"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
