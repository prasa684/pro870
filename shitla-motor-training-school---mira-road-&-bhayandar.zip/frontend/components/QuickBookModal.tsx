import React, { useState } from 'react';
import { X, CheckCircle, Car, Calendar, MapPin, User, Phone, ShieldCheck, ArrowRight } from 'lucide-react';
import { BRANCHES_DATA, COURSES_DATA } from '../data/contentData';
import { BookingFormData } from '../types';

interface QuickBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedCourseId?: string;
  preSelectedBranchId?: string;
}

export const QuickBookModal: React.FC<QuickBookModalProps> = ({
  isOpen,
  onClose,
  preSelectedCourseId,
  preSelectedBranchId,
}) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    phone: '',
    email: '',
    age: 22,
    preferredBranchId: preSelectedBranchId || BRANCHES_DATA[0].id,
    courseId: preSelectedCourseId || COURSES_DATA[0].id,
    preferredSlot: 'Morning (6 AM - 10 AM)',
    preferredInstructor: 'Any',
    pickupLocation: 'Near Residence',
    hasLearnerLicense: false,
    notes: '',
  });

  if (!isOpen) return null;

  const selectedCourse = COURSES_DATA.find((c) => c.id === formData.courseId) || COURSES_DATA[0];
  const selectedBranch = BRANCHES_DATA.find((b) => b.id === formData.preferredBranchId) || BRANCHES_DATA[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const resetAndClose = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-brand-900 to-slate-900 text-white p-6 relative">
          <button 
            onClick={resetAndClose}
            className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-full hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" /> Instant Online Admission Booking
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            Book Driving Slot at Shitla Motors
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Reserve your batch in Mira Road or Bhayandar. Free doorstep pickup on selected courses.
          </p>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-black text-slate-900">
              Application Confirmed!
            </h3>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              Thank you, <strong className="text-slate-800">{formData.fullName}</strong>. Our senior instructor from the <strong>{selectedBranch.subArea}</strong> branch has received your request.
            </p>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left max-w-md mx-auto space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Selected Course:</span>
                <span className="font-semibold text-slate-800">{selectedCourse.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Branch:</span>
                <span className="font-semibold text-slate-800">{selectedBranch.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Preferred Slot:</span>
                <span className="font-semibold text-slate-800">{formData.preferredSlot}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-sm">
                <span className="font-bold text-slate-700">Payable Fee:</span>
                <span className="font-extrabold text-brand-600">₹{selectedCourse.price.toLocaleString()}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <a
                href={`https://wa.me/${selectedBranch.whatsapp}?text=Hi,%20I%20have%20submitted%20the%20admission%20form%20for%20${encodeURIComponent(selectedCourse.title)}%20at%20${encodeURIComponent(selectedBranch.subArea)}%20branch.`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl transition"
              >
                Send Instant WhatsApp Notice
              </a>
              <button
                onClick={resetAndClose}
                className="px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm rounded-xl transition"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Step 1: Course & Branch Picker */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  1. Select Course / Package *
                </label>
                <select
                  value={formData.courseId}
                  onChange={(e) => setFormData({ ...formData, courseId: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-white"
                  required
                >
                  {COURSES_DATA.map((course) => (
                    <option key={course.id} value={course.id}>
                      {course.title} - ₹{course.price.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  2. Select Nearest Branch *
                </label>
                <select
                  value={formData.preferredBranchId}
                  onChange={(e) => setFormData({ ...formData, preferredBranchId: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-white"
                  required
                >
                  {BRANCHES_DATA.map((branch) => (
                    <option key={branch.id} value={branch.id}>
                      {branch.subArea} ({branch.landmark})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Price Preview Card */}
            <div className="bg-sky-50 border border-sky-100 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <div className="text-xs text-brand-700 font-semibold">{selectedCourse.title}</div>
                <div className="text-[11px] text-slate-500">Duration: {selectedCourse.durationDays} Days ({selectedCourse.sessionMinutes} mins daily)</div>
              </div>
              <div className="text-right">
                <span className="text-xs line-through text-slate-400 mr-1.5">₹{selectedCourse.originalPrice}</span>
                <span className="text-lg font-black text-brand-700">₹{selectedCourse.price.toLocaleString()}</span>
              </div>
            </div>

            {/* Personal Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name (As on Aadhaar) *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rahul Sharma"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mobile Number (WhatsApp) *
                </label>
                <input
                  type="tel"
                  placeholder="e.g. 98205XXXXX"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Age (Min 18 for LMV) *
                </label>
                <input
                  type="number"
                  min="18"
                  max="75"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) })}
                  className="w-full text-xs sm:text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred Time Slot
                </label>
                <select
                  value={formData.preferredSlot}
                  onChange={(e: any) => setFormData({ ...formData, preferredSlot: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-white"
                >
                  <option value="Morning (6 AM - 10 AM)">Morning (6 AM - 10 AM)</option>
                  <option value="Afternoon (11 AM - 3 PM)">Afternoon (11 AM - 3 PM)</option>
                  <option value="Evening (4 PM - 8 PM)">Evening (4 PM - 8 PM)</option>
                  <option value="Weekend Special">Weekend Special</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Trainer Preference
                </label>
                <select
                  value={formData.preferredInstructor}
                  onChange={(e: any) => setFormData({ ...formData, preferredInstructor: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-white"
                >
                  <option value="Any">Any Certified Trainer</option>
                  <option value="Female Instructor">Female Instructor (Lady)</option>
                  <option value="Senior Instructor">Senior Instructor (10+ Yrs)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Your Pickup Landmark / Locality in Mira Road or Bhayandar
              </label>
              <input
                type="text"
                placeholder="e.g. Near GCC Club / Shanti Nagar Sector 4 / Maxus Mall"
                value={formData.pickupLocation}
                onChange={(e) => setFormData({ ...formData, pickupLocation: e.target.value })}
                className="w-full text-xs sm:text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="llCheckbox"
                checked={formData.hasLearnerLicense}
                onChange={(e) => setFormData({ ...formData, hasLearnerLicense: e.target.checked })}
                className="rounded text-brand-600 focus:ring-brand-500 w-4 h-4 cursor-pointer"
              />
              <label htmlFor="llCheckbox" className="text-xs text-slate-600 cursor-pointer">
                I already have an active MH-04 Learner's License (Check if applicable)
              </label>
            </div>

            {/* CTA */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-sm uppercase tracking-wider rounded-xl shadow-lg transition transform active:scale-[0.98] flex items-center justify-center gap-2"
              >
                <span>Confirm Trial Booking & Lock Discount</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-[11px] text-center text-slate-400 mt-2">
                🔒 No advance payment needed online. Pay balance after your trial driving session at our branch.
              </p>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
