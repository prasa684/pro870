import React, { useState } from 'react';
import { 
  Car, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  Menu, 
  X, 
  BookOpen, 
  MessageCircle,
  Award,
  Compass
} from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onOpenBooking: () => void;
  onOpenAdvisor: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  currentPage, 
  onNavigate, 
  onOpenBooking,
  onOpenAdvisor 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'traffic-analysis', label: 'Traffic Analysis' },
    { id: 'services', label: 'Courses & Fees' },
    { id: 'branches', label: 'Branches (Mira-Bhayandar)' },
    { id: 'rto-guide', label: 'RTO MH-04 Guide' },
    { id: 'faq', label: 'FAQs & Schema' },
  ];

  const handleLinkClick = (pageId: string) => {
    onNavigate(pageId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white shadow-md">
      {/* Top Bar for Local Trust and Emergency Help */}
      <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 font-medium text-amber-400">
              <ShieldCheck className="w-3.5 h-3.5" /> Govt. Regd Driving School (MH-04 Thane)
            </span>
            <span className="hidden sm:inline text-slate-400">|</span>
            <span className="hidden sm:flex items-center gap-1 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-sky-400" /> Serving Mira Road & Bhayandar Since 2004
            </span>
          </div>
          <div className="flex items-center gap-4">
            <a 
              href="tel:+919820512341" 
              className="flex items-center gap-1 text-slate-200 hover:text-white font-semibold"
            >
              <Phone className="w-3.5 h-3.5 text-green-400" /> Helpline: +91 98205 12341
            </a>
            <button 
              onClick={onOpenAdvisor}
              className="hidden md:inline-flex items-center gap-1 text-xs bg-brand-700 hover:bg-brand-600 text-white px-2 py-0.5 rounded transition"
            >
              Ask AI Driving Coach
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Branding */}
          <div 
            className="flex items-center gap-3 cursor-pointer select-none"
            onClick={() => onNavigate('home')}
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-600 to-sky-500 flex items-center justify-center text-white shadow-lg shadow-sky-600/30">
              <Car className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
                  SHITLA
                </span>
                <span className="text-xs font-bold uppercase tracking-wider bg-amber-400 text-slate-950 px-1.5 py-0.5 rounded">
                  Motor Training
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium tracking-tight">
                Mira Road & Bhayandar’s #1 Rated Motor Driving School
              </p>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;
              const isHighlight = link.id === 'traffic-analysis';
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`px-3 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1 ${
                    isActive 
                      ? 'text-brand-600 bg-sky-50 font-bold' 
                      : isHighlight
                      ? 'text-amber-700 bg-amber-50 hover:bg-amber-100'
                      : 'text-slate-600 hover:text-brand-600 hover:bg-slate-100'
                  }`}
                >
                  {isHighlight && <Compass className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{link.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-2">
            <a
              href="https://wa.me/919820512341?text=Hi%20Shitla%20Motor%20Training,%20I%20want%20details%20for%20driving%20classes%20in%20Mira%20Road/Bhayandar"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>WhatsApp</span>
            </a>

            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-sm rounded-lg shadow-md hover:shadow-lg transition transform active:scale-95"
            >
              <BookOpen className="w-4 h-4" />
              <span>Book Trial Slot</span>
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={onOpenBooking}
              className="sm:hidden px-2.5 py-1.5 bg-amber-500 text-slate-950 text-xs font-bold rounded"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-6 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold flex items-center justify-between ${
                currentPage === link.id
                  ? 'bg-sky-50 text-brand-600'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="flex items-center gap-1.5">
                {link.id === 'traffic-analysis' && <Compass className="w-4 h-4 text-amber-500" />}
                {link.label}
              </span>
            </button>
          ))}
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdvisor();
              }}
              className="w-full py-2.5 text-center text-sm font-semibold bg-sky-100 text-sky-800 rounded-lg flex items-center justify-center gap-2"
            >
              <Award className="w-4 h-4" /> AI Driving & License Consultant
            </button>
            <a
              href="https://wa.me/919820512341"
              target="_blank"
              rel="noreferrer"
              className="w-full py-2.5 text-center text-sm font-semibold bg-emerald-600 text-white rounded-lg flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" /> Chat on WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
