import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { X, Sparkles, Send, Bot, User, Loader2, PhoneCall } from 'lucide-react';

interface GeminiAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBooking: () => void;
}

interface Message {
  sender: 'user' | 'ai';
  text: string;
}

export const GeminiAdvisorModal: React.FC<GeminiAdvisorModalProps> = ({
  isOpen,
  onClose,
  onOpenBooking,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: 'Namaste! I am the Shitla Motor Training Virtual Advisor. Ask me anything about driving courses in Mira Road or Bhayandar, Thane RTO (MH-04) license procedures, fee structures, or trainer timings!'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userText = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY, vertexai: true });
      const prompt = `
You are the senior driving counselor and local SEO assistant for "Shitla Motor Training School" located in Mira Road and Bhayandar (Thane District, Maharashtra, under MH-04 Thane RTO).
Key Information:
- Branches: 
  1. Mira Road East (Opposite Railway Station Platform 1)
  2. Mira Road Kanakia (Near Cinemax / Beverly Park)
  3. Bhayandar West (150 Feet Road near Maxus Mall)
  4. Bhayandar East (Navghar Road near flyover)
- Courses:
  - 4-Wheeler Manual (20 Days, ₹6,499) with full RTO License
  - 4-Wheeler Automatic AMT/CVT (15 Days, ₹7,499)
  - 2-Wheeler Geared/Activa (12 Days, ₹3,499)
  - 2W + 4W Combo (25 Days, ₹8,999)
  - Refresher Course for license holders (7 Days, ₹3,999)
- Features: Govt approved dual-control cars, certified lady instructors available, free doorstep pickup in Mira-Bhayandar, 98% first-try pass rate at Thane RTO.
- Thane RTO: Age 18+ for LMV, requires Aadhaar, age proof, photo.

User Question: "${userText}"

Reply in a helpful, friendly, professional tone. Keep answers concise (within 3-4 bullet points or 2 short paragraphs). Emphasize local Mira Road / Bhayandar landmarks when appropriate.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      const reply = response.text || 'I would be happy to connect you with our Mira Road desk at +91 98205 12341 for immediate admission assistance!';

      setMessages((prev) => [...prev, { sender: 'ai', text: reply }]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: 'Our Mira Road & Bhayandar branches are open today from 6:00 AM to 9:00 PM! For immediate assistance, feel free to call our main hotline: +91 98205 12341.'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[600px] max-h-[85vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-brand-900 to-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base">
                Shitla AI Driving & RTO Advisor
              </h3>
              <p className="text-[11px] text-sky-200">
                Instant answers on fees, Thane MH-04 rules & batch timings
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50 text-xs sm:text-sm">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-7 h-7 rounded-full bg-brand-700 text-white flex items-center justify-center shrink-0 mt-0.5 text-xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div
                className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-brand-600 text-white rounded-tr-none'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-sm'
                }`}
              >
                {m.text}
              </div>
              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center shrink-0 mt-0.5 text-xs">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs italic">
              <Loader2 className="w-4 h-4 animate-spin text-brand-600" />
              <span>Checking RTO guidelines and Shitla Motors schedule...</span>
            </div>
          )}
        </div>

        {/* Suggested Quick Prompts */}
        <div className="px-3 py-2 bg-slate-100 border-t border-slate-200 flex items-center gap-1.5 overflow-x-auto text-[11px]">
          <span className="text-slate-500 font-semibold shrink-0">Try asking:</span>
          <button
            onClick={() => setInput('What is the total fee for Automatic Car training with license?')}
            className="px-2.5 py-1 bg-white hover:bg-slate-200 border border-slate-300 rounded-full text-slate-700 whitespace-nowrap"
          >
            Automatic Car Fee?
          </button>
          <button
            onClick={() => setInput('Can I get a lady instructor in Bhayandar West?')}
            className="px-2.5 py-1 bg-white hover:bg-slate-200 border border-slate-300 rounded-full text-slate-700 whitespace-nowrap"
          >
            Lady Instructor in Bhayandar?
          </button>
          <button
            onClick={() => setInput('What documents are needed for Thane RTO Learner license?')}
            className="px-2.5 py-1 bg-white hover:bg-slate-200 border border-slate-300 rounded-full text-slate-700 whitespace-nowrap"
          >
            Required Documents?
          </button>
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your question (e.g. slot timings, pickup points)..."
            className="flex-1 text-xs sm:text-sm px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 bg-brand-600 hover:bg-brand-700 disabled:bg-slate-300 text-white rounded-xl transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
