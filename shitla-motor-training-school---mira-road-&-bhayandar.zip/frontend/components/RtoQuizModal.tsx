import React, { useState } from 'react';
import { X, CheckCircle2, XCircle, Award, RotateCcw, HelpCircle, ArrowRight } from 'lucide-react';
import { RTO_MOCK_QUESTIONS } from '../data/contentData';

interface RtoQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBooking: () => void;
}

export const RtoQuizModal: React.FC<RtoQuizModalProps> = ({ isOpen, onClose, onOpenBooking }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);

  if (!isOpen) return null;

  const currentQ = RTO_MOCK_QUESTIONS[currentIdx];
  const totalQ = RTO_MOCK_QUESTIONS.length;

  const handleSelect = (optionIdx: number) => {
    if (selectedAnswers[currentQ.id] !== undefined) return; // prevent re-answering
    setSelectedAnswers({
      ...selectedAnswers,
      [currentQ.id]: optionIdx,
    });
  };

  const handleNext = () => {
    if (currentIdx < totalQ - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setShowResults(true);
    }
  };

  const calculateScore = () => {
    let score = 0;
    RTO_MOCK_QUESTIONS.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        score++;
      }
    });
    return score;
  };

  const resetQuiz = () => {
    setCurrentIdx(0);
    setSelectedAnswers({});
    setShowResults(false);
  };

  const score = calculateScore();
  const passingScore = Math.ceil(totalQ * 0.6); // 60% passing in RTO

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-brand-800 to-sky-700 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                Thane RTO (MH-04) Learner’s Test Practice
              </h3>
              <p className="text-xs text-sky-200">
                Official syllabus traffic rules & road signage test
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-300 hover:text-white p-1 rounded-full hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {showResults ? (
            <div className="text-center space-y-4 py-4">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto text-3xl font-black ${
                score >= passingScore 
                  ? 'bg-emerald-100 text-emerald-700' 
                  : 'bg-rose-100 text-rose-700'
              }`}>
                {score}/{totalQ}
              </div>

              <div>
                <h4 className="text-xl font-black text-slate-900">
                  {score >= passingScore ? '🎉 Congratulations! You Passed!' : 'Needs Practice!'}
                </h4>
                <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
                  {score >= passingScore 
                    ? `You scored ${score} out of ${totalQ}. You are ready to crack the online computer test at Thane RTO.`
                    : `You scored ${score} out of ${totalQ}. The passing mark is ${passingScore}. Join Shitla Motor Training School for guaranteed first-attempt pass!`}
                </p>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={resetQuiz}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition"
                >
                  <RotateCcw className="w-4 h-4" /> Retake Test
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onOpenBooking();
                  }}
                  className="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition"
                >
                  Book Full Course & RTO Pass Kit
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Progress */}
              <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
                <span>Question {currentIdx + 1} of {totalQ}</span>
                <span className="bg-sky-100 text-sky-800 px-2 py-0.5 rounded font-bold">
                  {currentQ.category}
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-1.5">
                <div 
                  className="bg-brand-600 h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${((currentIdx + 1) / totalQ) * 100}%` }}
                />
              </div>

              {/* Question */}
              <h4 className="text-base font-bold text-slate-900 pt-2 leading-snug">
                {currentQ.question}
              </h4>

              {/* Options */}
              <div className="space-y-2.5 pt-2">
                {currentQ.options.map((option, idx) => {
                  const isChosen = selectedAnswers[currentQ.id] === idx;
                  const isAnswered = selectedAnswers[currentQ.id] !== undefined;
                  const isCorrect = idx === currentQ.correctIndex;

                  let btnStyle = 'border-slate-200 hover:border-brand-500 bg-white text-slate-700';

                  if (isAnswered) {
                    if (isCorrect) {
                      btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold';
                    } else if (isChosen) {
                      btnStyle = 'border-rose-500 bg-rose-50 text-rose-900 font-semibold';
                    } else {
                      btnStyle = 'border-slate-200 bg-slate-50 text-slate-400 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelect(idx)}
                      disabled={isAnswered}
                      className={`w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm transition flex items-center justify-between ${btnStyle}`}
                    >
                      <span>{option}</span>
                      {isAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 ml-2" />}
                      {isAnswered && isChosen && !isCorrect && <XCircle className="w-4 h-4 text-rose-600 shrink-0 ml-2" />}
                    </button>
                  );
                })}
              </div>

              {/* Explanation Note */}
              {selectedAnswers[currentQ.id] !== undefined && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                  <strong>Explanation:</strong> {currentQ.explanation}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer actions */}
        {!showResults && (
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
            <button
              onClick={handleNext}
              disabled={selectedAnswers[currentQ.id] === undefined}
              className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                selectedAnswers[currentQ.id] !== undefined
                  ? 'bg-brand-600 hover:bg-brand-700 text-white cursor-pointer'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span>{currentIdx === totalQ - 1 ? 'View Final Result' : 'Next Question'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
