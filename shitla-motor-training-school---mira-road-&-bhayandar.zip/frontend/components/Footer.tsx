import React from 'react';
import { 
  Car, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ShieldCheck, 
  Award, 
  CheckCircle2, 
  ChevronRight,
  Code,
  Compass
} from 'lucide-react';
import { BRANCHES_DATA } from '../data/contentData';

interface FooterProps {
  onNavigate: (page: string) => void;
  onOpenSchema: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenSchema }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Brand & RTO Accreditation */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-white">
              <div className="w-10 h-10 rounded-lg bg-brand-600 flex items-center justify-center text-white">
                <Car className="w-6 h-6" />
              </div>
              <span className="text-xl font-black tracking-tight">SHITLA MOTORS</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Govt. Authorized Driving School in Mira Road & Bhayandar. Empowering 25,000+ confident drivers with certified instructors, dual-control cars, and seamless Thane RTO (MH-04) licensing.
            </p>
            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                <ShieldCheck className="w-4 h-4" /> Maharashtra RTO License #MH04-TR-841
              </div>
              <p className="text-[11px] text-slate-400">
                Affiliated with Regional Transport Office Thane (MH-04).
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-4 border-l-4 border-brand-500 pl-2">
              Courses & Analytics
            </h3>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('traffic-analysis')} className="text-amber-400 hover:text-amber-300 flex items-center gap-1.5 transition font-semibold">
                  <Compass className="w-3.5 h-3.5" /> Traffic & Route Analysis
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-white flex items-center gap-1.5 transition">
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" /> 4-Wheeler Manual Training
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-white flex items-center gap-1.5 transition">
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" /> Automatic (AMT/CVT) Car Classes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-white flex items-center gap-1.5 transition">
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" /> Lady Instructor Special Batch
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('rto-guide')} className="hover:text-white flex items-center gap-1.5 transition">
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" /> Thane RTO Learner’s Test Prep
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-white flex items-center gap-1.5 transition">
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" /> Refresher Road Confidence Drive
                </button>
              </li>
            </ul>
          </div>

          {/* Local Service Areas Directory */}
          <div>
            <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-4 border-l-4 border-amber-500 pl-2">
              Mira-Bhayandar Localities
            </h3>
            <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 text-xs text-slate-400">
              <span className="flex items-center gap-1">📍 Shanti Nagar</span>
              <span className="flex items-center gap-1">📍 Maxus Mall 150ft</span>
              <span className="flex items-center gap-1">📍 Kanakia Road</span>
              <span className="flex items-center gap-1">📍 Navghar Road</span>
              <span className="flex items-center gap-1">📍 Beverly Park</span>
              <span className="flex items-center gap-1">📍 Jesal Park</span>
              <span className="flex items-center gap-1">📍 Silver Park</span>
              <span className="flex items-center gap-1">📍 Balaji Nagar</span>
              <span className="flex items-center gap-1">📍 Poonam Sagar</span>
              <span className="flex items-center gap-1">📍 Indralok Phase</span>
              <span className="flex items-center gap-1">📍 Jangid Enclave</span>
              <span className="flex items-center gap-1">📍 Hatkesh Udyog</span>
            </div>
            <p className="mt-3 text-[11px] text-slate-500">
              *Free doorstep pickup & drop in our dual-control training vehicles for selected batches.
            </p>
          </div>

          {/* Contact & Branches Snapshot */}
          <div className="space-y-3">
            <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-4 border-l-4 border-emerald-500 pl-2">
              Head Office Contact
            </h3>
            <p className="text-xs text-slate-400 flex items-start gap-2">
              <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>Shop 7, Shanti Shopping Centre, Opp. Mira Road Station, Thane 401107</span>
            </p>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>+91 98205 12341 / +91 98205 12342</span>
            </p>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <Mail className="w-4 h-4 text-sky-400 shrink-0" />
              <span>info@shitlamotors.com</span>
            </p>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Mon - Sun: 6:00 AM - 9:00 PM</span>
            </p>

            <button
              onClick={onOpenSchema}
              className="mt-2 w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded border border-slate-600 flex items-center justify-center gap-1.5 transition"
            >
              <Code className="w-3.5 h-3.5 text-amber-400" />
              <span>View Local SEO JSON-LD Schemas</span>
            </button>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} Shitla Motor Training School. All rights reserved. Registered under Govt of Maharashtra Transport Dept.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => onNavigate('traffic-analysis')} className="text-amber-400 hover:underline">Traffic Analysis</button>
            <span>•</span>
            <button onClick={() => onNavigate('branches')} className="hover:text-slate-300">Branches</button>
            <span>•</span>
            <button onClick={() => onNavigate('faq')} className="hover:text-slate-300">FAQ Schema</button>
            <span>•</span>
            <button onClick={() => onNavigate('rto-guide')} className="hover:text-slate-300">MH-04 Thane RTO</button>
          </div>
        </div>

      </div>
    </footer>
  );
};
