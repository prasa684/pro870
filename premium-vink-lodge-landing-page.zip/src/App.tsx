import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";

const stayOptions = [
  { name: "Forest room", price: "NOK 2,950", detail: "A quiet room for two" },
  { name: "Lake suite", price: "NOK 4,200", detail: "A little more room to linger" },
  { name: "The whole lodge", price: "NOK 28,000", detail: "A private stay for your people" },
];

const guestNotes = [
  {
    quote:
      "We came for a weekend and left feeling like we'd been away for a week. The quiet does something to you here.",
    name: "Maja & Erik",
    place: "Guests from Bergen",
  },
  {
    quote:
      "No itinerary, no rush, nowhere else to be. Somehow that became the most memorable trip we've taken.",
    name: "Sophie L.",
    place: "Guest from Copenhagen",
  },
  {
    quote:
      "The sauna, the lake, the long breakfast. We have already found a reason to come back.",
    name: "Jonas & Liv",
    place: "Guests from Oslo",
  },
];

const faqItems = [
  {
    question: "Where is Vink Lodge?",
    answer:
      "We are tucked into a quiet corner of Northern Norway, where the spruce forest meets the water. Your booking confirmation includes the exact directions and everything you need for the journey.",
  },
  {
    question: "What is included in a stay?",
    answer:
      "Every stay includes a slow breakfast made with local ingredients, thoughtful in-room essentials, and time in our wood-fired sauna. Your confirmation will outline the details for your chosen room.",
  },
  {
    question: "When is the best time to visit?",
    answer:
      "There is no wrong season. Summer brings long, bright evenings and wild swimming; autumn is all colour and calm; winter is made for sauna warmth, snow-soft trails, and a chance of northern lights.",
  },
  {
    question: "Can I bring my dog?",
    answer:
      "A small number of our rooms can welcome a well-behaved dog. Let us know when you enquire and we will find the right room for you both.",
  },
];

function toDateInputValue(date: Date) {
  const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return localDate.toISOString().slice(0, 10);
}

function nextDateInputValue(value: string) {
  const nextDate = new Date(`${value}T12:00:00`);
  nextDate.setDate(nextDate.getDate() + 1);
  return toDateInputValue(nextDate);
}

function formatStayDate(value: string) {
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function ArrowIcon({ diagonal = false }: { diagonal?: boolean }) {
  return diagonal ? (
    <svg aria-hidden="true" viewBox="0 0 20 20" fill="none" className="icon-arrow">
      <path d="M4.5 15.5 15 5M6 5h9v9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ) : (
    <svg aria-hidden="true" viewBox="0 0 20 20" fill="none" className="icon-arrow">
      <path d="M3.5 10h12m-5-5 5 5-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function BrandMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 38 38" fill="none" className="brand-mark">
      <path d="M19 3.75c7.05 0 12.75 5.7 12.75 12.75S26.05 29.25 19 29.25 6.25 23.55 6.25 16.5" stroke="currentColor" strokeWidth="1.2" />
      <path d="M19 9.2v20.1M11.4 17.1H19m0 4.4h7.2M13.4 9.8 19 15.4l5.6-5.6M19 29.2l-5.4 5.05M19 29.2l5.4 5.05" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="19" cy="16.5" r="1.35" fill="currentColor" />
    </svg>
  );
}

function BookingDialog({
  open,
  initialStay,
  onClose,
}: {
  open: boolean;
  initialStay: string;
  onClose: () => void;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const [stay, setStay] = useState(initialStay);
  const [arrival, setArrival] = useState("");
  const [departure, setDeparture] = useState("");
  const [guests, setGuests] = useState("2");
  const [requestReady, setRequestReady] = useState(false);
  const confirmationHeadingRef = useRef<HTMLHeadingElement>(null);
  const minDate = toDateInputValue(new Date());
  const minDeparture = arrival ? nextDateInputValue(arrival) : minDate;

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;

    if (open && !dialog.open) {
      dialog.showModal();
      setStay(initialStay);
      setArrival("");
      setDeparture("");
      setGuests("2");
      setRequestReady(false);
      window.requestAnimationFrame(() => closeRef.current?.focus());
    } else if (!open && dialog.open) {
      dialog.close();
    }
  }, [open, initialStay]);

  useEffect(() => {
    if (requestReady) window.requestAnimationFrame(() => confirmationHeadingRef.current?.focus());
  }, [requestReady]);

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setRequestReady(true);
  };

  const selectedStay = stayOptions.find((option) => option.name === stay);
  const emailSubject = encodeURIComponent(`Stay enquiry: ${stay}`);
  const emailBody = encodeURIComponent(
    `Hello Vink Lodge,\n\nI'd love to ask about a stay.\n\nStay: ${stay}\nArrival: ${arrival}\nDeparture: ${departure}\nGuests: ${guests}\n\nPlease let me know what might be available.\n\nThank you!`,
  );

  return (
    <dialog
      className="booking-dialog"
      ref={dialogRef}
      aria-labelledby="booking-title"
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="booking-dialog__body">
        <button
          className="booking-dialog__close"
          type="button"
          onClick={onClose}
          aria-label="Close booking enquiry"
          ref={closeRef}
        >
          <span />
          <span />
        </button>
        <span className="eyebrow">A LITTLE TIME AWAY</span>
        <h2 id="booking-title">Your quiet starts here.</h2>
        <p className="booking-dialog__intro">
          Tell us what you have in mind. We will help you find the right stay.
        </p>

        {!requestReady ? (
          <form className="booking-form" onSubmit={onSubmit}>
            <label className="booking-field booking-field--wide">
              <span>Your stay</span>
              <select value={stay} onChange={(event) => setStay(event.target.value)}>
                {stayOptions.map((option) => (
                  <option key={option.name} value={option.name}>
                    {option.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="booking-field">
              <span>Arrival</span>
              <input
                type="date"
                value={arrival}
                min={minDate}
                onChange={(event) => {
                  setArrival(event.target.value);
                  setDeparture("");
                }}
                required
              />
            </label>
            <label className="booking-field">
              <span>Departure</span>
              <input
                type="date"
                value={departure}
                min={minDeparture}
                onChange={(event) => {
                  setDeparture(event.target.value);
                  setRequestReady(false);
                }}
                required
              />
            </label>
            <label className="booking-field booking-field--wide">
              <span>Guests</span>
              <select value={guests} onChange={(event) => setGuests(event.target.value)}>
                {[1, 2, 3, 4, 5, 6, 8, 10, 12].map((count) => (
                  <option key={count} value={count}>
                    {count} {count === 1 ? "guest" : "guests"}
                  </option>
                ))}
              </select>
            </label>
            <button className="button button--dark booking-form__submit" type="submit">
              Prepare my enquiry <ArrowIcon />
            </button>
            <p className="booking-form__note">
              No payment, no pressure. Just a personal reply from our hosts.
            </p>
          </form>
        ) : (
          <div className="booking-confirmation" aria-live="polite">
            <div className="booking-confirmation__mark" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none">
                <path d="m5 12.5 4.5 4.5L19.5 7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h3 ref={confirmationHeadingRef} tabIndex={-1}>A lovely idea.</h3>
            <p>
              {selectedStay?.name} for {guests} {Number(guests) === 1 ? "guest" : "guests"}, from {formatStayDate(arrival)} to {formatStayDate(departure)}.
            </p>
            <a
              className="button button--dark booking-form__submit"
              href={`mailto:stay@vinklodge.com?subject=${emailSubject}&body=${emailBody}`}
            >
              Email your stay enquiry <ArrowIcon />
            </a>
            <p className="booking-form__note">
              Your email app will open with these details ready. Your stay is confirmed personally by our hosts.
            </p>
            <button className="booking-confirmation__edit" type="button" onClick={() => setRequestReady(false)}>
              Change my details
            </button>
          </div>
        )}
      </div>
    </dialog>
  );
}

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedStay, setSelectedStay] = useState("Forest room");
  const [activeNote, setActiveNote] = useState(0);

  const openBooking = useCallback((stay = "Forest room") => {
    setSelectedStay(stay);
    setBookingOpen(true);
    setMenuOpen(false);
  }, []);

  const closeBooking = useCallback(() => setBookingOpen(false), []);

  useEffect(() => {
    const updateHeader = () => setIsScrolled(window.scrollY > 32);
    updateHeader();
    window.addEventListener("scroll", updateHeader, { passive: true });
    return () => window.removeEventListener("scroll", updateHeader);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [menuOpen]);

  useEffect(() => {
    const revealElements = document.querySelectorAll<HTMLElement>(".reveal:not(.is-visible)");
    if (!("IntersectionObserver" in window)) {
      revealElements.forEach((element) => element.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -42px 0px" },
    );

    revealElements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  const showPreviousNote = () => {
    setActiveNote((current) => (current - 1 + guestNotes.length) % guestNotes.length);
  };
  const showNextNote = () => {
    setActiveNote((current) => (current + 1) % guestNotes.length);
  };

  const navigation = [
    { label: "The lodge", href: "#the-lodge" },
    { label: "The feeling", href: "#the-feeling" },
    { label: "Stay & rates", href: "#rates" },
    { label: "Good to know", href: "#faq" },
  ];

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell" id="top">
      <a className="skip-link" href="#main-content">Skip to content</a>

      <header className={`site-header${isScrolled ? " is-scrolled" : ""}${menuOpen ? " menu-open" : ""}`}>
        <div className="site-header__inner">
          <a className="brand" href="#top" aria-label="Vink Lodge home" onClick={closeMenu}>
            <BrandMark />
            <span className="brand__text">
              <span>VINK</span>
              <small>LODGE</small>
            </span>
          </a>

          <nav className="desktop-nav" aria-label="Main navigation">
            {navigation.map((item) => (
              <a key={item.href} href={item.href}>{item.label}</a>
            ))}
          </nav>

          <button className="header-book" type="button" onClick={() => openBooking()}>
            <span>Book your stay</span><ArrowIcon />
          </button>

          <button
            className={`menu-toggle${menuOpen ? " is-open" : ""}`}
            type="button"
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={menuOpen}
            aria-controls="mobile-navigation"
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span /><span />
          </button>
        </div>
        <nav className="mobile-nav" id="mobile-navigation" aria-label="Mobile navigation" hidden={!menuOpen}>
          {navigation.map((item, index) => (
            <a key={item.href} href={item.href} onClick={closeMenu}>
              <span className="mobile-nav__index">0{index + 1}</span>{item.label}<ArrowIcon />
            </a>
          ))}
          <button type="button" onClick={() => openBooking()}>
            Find your stay <ArrowIcon />
          </button>
        </nav>
      </header>

      <main id="main-content">
        <section className="hero" aria-labelledby="hero-title">
          <img className="hero__image" src="/images/vink-hero.jpg" alt="" aria-hidden="true" fetchPriority="high" />
          <div className="hero__wash" aria-hidden="true" />
          <div className="hero__content">
            <p className="hero__overline hero-enter hero-enter--one">A quieter kind of getaway</p>
            <h1 className="hero__title hero-enter hero-enter--two" id="hero-title">
              <span>Vink</span> <i>Lodge</i>
            </h1>
            <p className="hero__description hero-enter hero-enter--three">
              Find your way back to stillness.
              <span>Somewhere between the forest and the water.</span>
            </p>
            <div className="hero__actions hero-enter hero-enter--four">
              <button className="button button--light" type="button" onClick={() => openBooking()}>
                Find your stay <ArrowIcon />
              </button>
              <a className="text-link text-link--light" href="#the-lodge">
                Discover the lodge <ArrowIcon />
              </a>
            </div>
          </div>
          <a className="hero__scroll" href="#a-note" aria-label="Scroll to discover Vink Lodge">
            <span>Scroll to discover</span>
            <span className="hero__scroll-line" />
          </a>
        </section>

        <section className="praise-strip" id="a-note" aria-label="A note from a recent guest">
          <div className="praise-strip__stars" aria-hidden="true">
            {[0, 1, 2, 3, 4].map((star) => (
              <svg key={star} viewBox="0 0 16 16" aria-hidden="true">
                <path d="m8 1.3 2.05 4.16 4.6.67-3.33 3.24.78 4.58L8 11.79l-4.1 2.16.78-4.58L1.35 6.13l4.6-.67L8 1.3Z" fill="currentColor" />
              </svg>
            ))}
          </div>
          <p>"We came for the quiet. We left carrying it with us."</p>
          <span className="praise-strip__source">A note from a recent guest</span>
          <a className="praise-strip__link" href="#guest-notes" aria-label="Read guest notes">
            <ArrowIcon />
          </a>
        </section>

        <section className="experience section-pad" id="experience" aria-labelledby="experience-title">
          <div className="section-heading reveal">
            <p className="eyebrow">The Vink feeling</p>
            <h2 id="experience-title">A little less doing.<br /><em>A lot more being.</em></h2>
            <p className="section-heading__copy">
              Made for the moments that do not need a plan. Just good company, fresh air, and room to be exactly where you are.
            </p>
          </div>
          <div className="experience-list">
            <article className="experience-item reveal reveal--delay-1">
              <span className="experience-item__index">01</span>
              <div>
                <h3>Wake up somewhere wild</h3>
                <p>Slow mornings, soft linen, and the forest waiting just outside.</p>
              </div>
              <span className="experience-item__symbol" aria-hidden="true"><ArrowIcon diagonal /></span>
            </article>
            <article className="experience-item reveal reveal--delay-2">
              <span className="experience-item__index">02</span>
              <div>
                <h3>Follow the feeling</h3>
                <p>Take the trail, find the water, or stay right where you are.</p>
              </div>
              <span className="experience-item__symbol" aria-hidden="true"><ArrowIcon diagonal /></span>
            </article>
            <article className="experience-item reveal reveal--delay-3">
              <span className="experience-item__index">03</span>
              <div>
                <h3>Warm up. Wind down.</h3>
                <p>A wood-fired sauna, a long supper, and nowhere else to be.</p>
              </div>
              <span className="experience-item__symbol" aria-hidden="true"><ArrowIcon diagonal /></span>
            </article>
          </div>
        </section>

        <section className="lodge-section" id="the-lodge" aria-labelledby="lodge-title">
          <div className="lodge-section__image-wrap reveal">
            <img
              className="lodge-section__image"
              src="/images/vink-room.jpg"
              alt="A calm lodge bedroom with a picture window opening onto the forest and lake"
              loading="lazy"
            />
            <span className="image-caption">A room of your own</span>
          </div>
          <div className="lodge-section__copy reveal reveal--delay-1">
            <p className="eyebrow">Come in, slow down</p>
            <h2 id="lodge-title">Room for a<br /><em>slower rhythm.</em></h2>
            <p className="lodge-section__description">
              Natural textures. Thoughtful details. Nothing you need, and nothing you do not. Our rooms are made to make the outside world feel a little further away.
            </p>
            <ul className="room-details">
              <li><span>01</span> Linen made for deep sleep</li>
              <li><span>02</span> Wide windows, wild views</li>
              <li><span>03</span> Slow breakfast, every morning</li>
            </ul>
            <button className="text-link text-link--dark" type="button" onClick={() => openBooking("Lake suite")}>
              Find your room <ArrowIcon />
            </button>
          </div>
        </section>

        <section className="feeling-section" id="the-feeling" aria-labelledby="feeling-title">
          <div className="feeling-section__inner">
            <div className="feeling-section__intro reveal">
              <p className="eyebrow eyebrow--light">More of what matters</p>
              <h2 id="feeling-title">Leave with a little<br /><em>more space.</em></h2>
            </div>
            <div className="benefit-list">
              <article className="benefit-item reveal reveal--delay-1">
                <span>01</span>
                <div><h3>Space to exhale</h3><p>Sleep well. Wake gently. Let your shoulders drop.</p></div>
              </article>
              <article className="benefit-item reveal reveal--delay-2">
                <span>02</span>
                <div><h3>Space to wander</h3><p>Quiet trails, open water, and a little room to get lost.</p></div>
              </article>
              <article className="benefit-item reveal reveal--delay-3">
                <span>03</span>
                <div><h3>Space for each other</h3><p>Long conversations, shared meals, and time that is yours.</p></div>
              </article>
            </div>
          </div>
          <div className="feeling-section__glow" aria-hidden="true" />
        </section>

        <section className="sauna-section" aria-labelledby="sauna-title">
          <img
            className="sauna-section__image"
            src="/images/vink-sauna.jpg"
            alt="The warm timber interior of a lakeside sauna looking out to the forest"
            loading="lazy"
          />
          <div className="sauna-section__overlay" aria-hidden="true" />
          <div className="sauna-section__copy reveal">
            <p className="eyebrow eyebrow--light">A Vink ritual</p>
            <h2 id="sauna-title">Heat. Hush.<br /><em>Cold water.</em></h2>
            <p>Let the wood stove crackle. Let the steam rise. Then step outside and feel the lake air wake you up.</p>
            <a className="text-link text-link--light" href="#rates">Make room for a sauna <ArrowIcon /></a>
          </div>
          <span className="sauna-section__caption">The best kind of after-hours</span>
        </section>

        <section className="guest-notes section-pad" id="guest-notes" aria-labelledby="guest-notes-title">
          <div className="guest-notes__heading reveal">
            <p className="eyebrow">A few words, kept close</p>
            <h2 id="guest-notes-title">The feeling<br /><em>stays with you.</em></h2>
          </div>
          <div className="quote-slider reveal reveal--delay-1" aria-live="polite" aria-atomic="true">
            <span className="quote-slider__mark" aria-hidden="true">&quot;</span>
            <blockquote key={activeNote} className="quote-slider__quote">
              {guestNotes[activeNote].quote}
            </blockquote>
            <div className="quote-slider__footer">
              <div className="quote-slider__attribution">
                <span>{guestNotes[activeNote].name}</span>
                <span>{guestNotes[activeNote].place}</span>
              </div>
              <div className="quote-slider__controls">
                <span className="quote-slider__count">0{activeNote + 1} <i>/</i> 0{guestNotes.length}</span>
                <button type="button" onClick={showPreviousNote} aria-label="Previous guest note">
                  <ArrowIcon />
                </button>
                <button type="button" onClick={showNextNote} aria-label="Next guest note">
                  <ArrowIcon />
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="rates-section section-pad" id="rates" aria-labelledby="rates-title">
          <div className="rates-section__top reveal">
            <div>
              <p className="eyebrow">Stay a little longer</p>
              <h2 id="rates-title">Choose your kind<br /><em>of quiet.</em></h2>
            </div>
            <p>Every stay includes breakfast, the good bits, and the freedom to do very little. Find the one that feels like you.</p>
          </div>
          <div className="rates-list">
            {stayOptions.map((option, index) => (
              <article className="rate-row reveal" key={option.name}>
                <span className="rate-row__index">0{index + 1}</span>
                <div className="rate-row__name">
                  <h3>{option.name}</h3>
                  <p>{option.detail}</p>
                </div>
                <div className="rate-row__price">
                  <strong>{option.price}</strong>
                  <span>from / night</span>
                </div>
                <button className="rate-row__action" type="button" onClick={() => openBooking(option.name)} aria-label={`Enquire about ${option.name}`}>
                  <ArrowIcon />
                </button>
              </article>
            ))}
          </div>
          <p className="rates-section__note reveal">Rates vary by season and room. We will confirm your exact price before anything is booked.</p>
        </section>

        <section className="faq-section section-pad" id="faq" aria-labelledby="faq-title">
          <div className="faq-section__intro reveal">
            <p className="eyebrow">Before you wander</p>
            <h2 id="faq-title">A few useful<br /><em>things to know.</em></h2>
            <p>Still wondering about something? We would love to help.</p>
            <a href="mailto:stay@vinklodge.com" className="faq-section__email">Talk to a real person <ArrowIcon /></a>
          </div>
          <div className="faq-list">
            {faqItems.map((item) => (
              <details className="faq-item reveal" key={item.question}>
                <summary>
                  <span>{item.question}</span>
                  <span className="faq-item__icon" aria-hidden="true" />
                </summary>
                <div className="faq-item__answer"><p>{item.answer}</p></div>
              </details>
            ))}
          </div>
        </section>

        <section className="closing-cta" aria-labelledby="closing-title">
          <div className="closing-cta__glow" aria-hidden="true" />
          <div className="closing-cta__content reveal">
            <p className="eyebrow eyebrow--light">The forest can wait</p>
            <h2 id="closing-title">Make room for<br /><em>nowhere to be.</em></h2>
            <p>Come as you are. Leave a little lighter.</p>
            <button className="button button--light" type="button" onClick={() => openBooking()}>
              Find your stay <ArrowIcon />
            </button>
          </div>
          <div className="closing-cta__ornament" aria-hidden="true"><BrandMark /></div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="site-footer__top">
          <div className="site-footer__brand">
            <a className="brand brand--footer" href="#top" aria-label="Vink Lodge home">
              <BrandMark />
              <span className="brand__text"><span>VINK</span><small>LODGE</small></span>
            </a>
            <p>A quieter corner of Northern Norway.<br />A little closer to yourself.</p>
          </div>
          <div className="site-footer__column">
            <span className="site-footer__label">Find your way</span>
            <a href="#the-lodge">The lodge</a>
            <a href="#the-feeling">The feeling</a>
            <a href="#rates">Stay & rates</a>
          </div>
          <div className="site-footer__column">
            <span className="site-footer__label">Say hello</span>
            <a href="mailto:stay@vinklodge.com">stay@vinklodge.com</a>
            <a href="tel:+4777000000">+47 77 00 00 00</a>
            <a href="#faq">Getting here</a>
          </div>
          <div className="site-footer__column site-footer__social">
            <span className="site-footer__label">Follow the quiet</span>
            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer">Instagram <ArrowIcon diagonal /></a>
            <a href="https://www.pinterest.com/" target="_blank" rel="noreferrer">Pinterest <ArrowIcon diagonal /></a>
          </div>
        </div>
        <div className="site-footer__bottom">
          <span>Copyright {new Date().getFullYear()} Vink Lodge. Made for slower days.</span>
          <a href="#top">Back to the beginning <ArrowIcon /></a>
          <span>Privacy | Terms</span>
        </div>
      </footer>

      <BookingDialog open={bookingOpen} initialStay={selectedStay} onClose={closeBooking} />
    </div>
  );
}